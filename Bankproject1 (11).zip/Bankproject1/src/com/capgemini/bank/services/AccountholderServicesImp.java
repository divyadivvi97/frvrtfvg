package com.capgemini.bank.services;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;

import com.capgemini.bank.beans.Accountholder;
import com.capgemini.bank.beans.Transaction;
import com.capgemini.bank.dao.AccountholderDAOImp;
import com.capgemini.bank.exceptions.AccountholderException;
import com.capgemini.bank.utility.JPAUtil;

public class  AccountholderServicesImp implements IAccountholderServices{
	AccountholderDAOImp dao= new AccountholderDAOImp();
	
	public boolean createAccount(Accountholder bean) throws AccountholderException
	{
		return dao.createAccount(bean);
		
	}
	public Accountholder displayAccountholder1(long id3) throws AccountholderException {
		
		return dao.displayAccountholder1(id3);
	}

	public double showBalance(Accountholder m) throws AccountholderException
	{
		return dao.showBalance(m);
		
	}

	public double deposit(Accountholder e,double amount) throws AccountholderException
	{
		return dao.deposit(e,amount);
	}
	
	public double withDraw(Accountholder d,double amount) throws AccountholderException
	{
		return dao.withDraw(d,amount);
	}
	
	public int fundTransfer(Accountholder b,Accountholder c,double amount) throws AccountholderException{
		return dao.fundTransfer(b,c,amount);
	}
	
	public List<Transaction> printTrans(long id7) throws AccountholderException{
		return dao.printTrans(id7);
		
	}

	public boolean valid(long id3) throws AccountholderException
	{
		boolean flag=false;


		EntityManager em=null;	
		try{

			em=JPAUtil.getEntityManager();

			Accountholder a= em.find(Accountholder.class, id3);
			if(a==null){
				return flag;
			}
			else if(a.getaccountNumber()==id3)
			{
				flag=true;
			}
			return flag;
		}
		catch(PersistenceException e) {
			e.printStackTrace();

			throw new AccountholderException(e.getMessage());
		}finally {
			em.close();
		}

	}
	public boolean validateChoice(String choice){
		boolean flag=false;
		Pattern pattern=Pattern.compile("[0-7]");
		Matcher m = pattern.matcher(choice);
		if(m.matches())
		{
		 flag=true;
		}
		return flag;
	}
	public boolean validateAccnoPinno(Accountholder m,long id,int pin)
	{ 
		boolean flag=false;
	if((m.getaccountNumber()==id)&&(m.getpinNumber()==pin)){
			flag=true;
		}
		return flag;
				}
	public boolean validateAccountholderName(String accName){
		boolean flag=true;
		Pattern pattern=Pattern.compile("[A-za-z]*");
		Matcher m = pattern.matcher(accName);
		if((m.matches()) && (accName.length()>2))
		{
			flag=false;
		}
		return flag;
	}
public boolean validateAddress(String address){
	boolean flag=true;
	Pattern pattern=Pattern.compile("[A-Z]{1}[a-z]*");
	Matcher m = pattern.matcher(address);
	if(m.matches())
	{
	 flag=false;
	}
	return flag;
}
	public boolean validateMobileNumber(String mobileNumber){
		boolean flag=true;
		Pattern pattern=Pattern.compile("[7-9][0-9]{9}");
		Matcher m = pattern.matcher(mobileNumber);
		if(m.matches())
		{
		 flag=false;
		}
		return flag;
	}
	
	public boolean validateAdhaarNumber(String adhaarNumber){
		boolean flag=true;
		Pattern pattern=Pattern.compile("[0-9][0-9]{9}");
		Matcher m = pattern.matcher(adhaarNumber);
		if(m.matches())
		{
		 flag=false;
		}
		return flag;
	}
	public boolean validateAge(int age){
		boolean flag=false;
	
		if(age>18)
		{
			flag=false;
		}
		return flag;
	}
	
	public boolean validateEmailId(String emailid){
		boolean flag=true;
		Pattern pattern=Pattern.compile("[a-zA-Z0-9.]*@[a-zA-Z0-9]+([.][a-zA-z]+)");
		Matcher m = pattern.matcher(emailid);
		if(m.matches())
		{
		 flag=false;
		}
		return flag;
	}
	
	}

