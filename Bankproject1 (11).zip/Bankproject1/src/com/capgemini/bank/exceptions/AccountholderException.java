package com.capgemini.bank.exceptions;

public class AccountholderException extends Exception {

	public AccountholderException(String Message)
		{
			super(Message);
		}

	public void getMessage(String string) {
		// TODO Auto-generated method stub
		
	}

	

	}

