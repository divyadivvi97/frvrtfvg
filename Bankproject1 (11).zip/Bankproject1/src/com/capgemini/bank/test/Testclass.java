package com.capgemini.bank.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.bank.beans.Accountholder;
import com.capgemini.bank.exceptions.AccountholderException;
import com.capgemini.bank.services.AccountholderServicesImp;

public class Testclass extends AccountholderServicesImp {
	
	Accountholder a= new Accountholder(1,"divya","Telanagna",45,
			null,"8956859623", "8956985698",(int)(Math.random()*100000),
			10000);
	Accountholder b= new Accountholder(2,"bhavani","Telanagna",54,
			null,"8956895653", "8985962398",(int)(Math.random()*100000),
			1000);
	AccountholderServicesImp c = new AccountholderServicesImp();
	
	@Test
	public void testCreateAccount() throws AccountholderException {
		//assertNotNull(c.createAccount(a));
		a.setemailId("divyadivvi97@gmail.com");
		b.setemailId("bhavani@hotmail.com");
		boolean d=c.createAccount(a);
		boolean e=c.createAccount(b);
		assertTrue(d==true);
		assertTrue(e==true);
	}

	

	@Test
	public void testShowBalance() {
		
		assertEquals(10000, a.getBalance(),0.1);
		//(a.getBalance(), c.showBalance(a));
	}

	@Test
	public void testDeposit() throws AccountholderException {
		double f=c.deposit(a,1000);
		assertEquals(11000, a.getBalance(),0.1);
		
	}

	@Test
	public void testWithDraw() throws AccountholderException {
		double withdraw=c.withDraw(b,200);
		b.setBalance(withdraw);
		assertEquals(800,b.getBalance(),0.1);
		
	}

	
	@Test
	public void testFundTransfer() throws AccountholderException {
		double a3= c.fundTransfer(a,b,1000);
		
		assertEquals(9000, a.getBalance(),0.1);
		assertNotEquals(1000,b.getBalance(),0.1);
		
	}

	@Test
	public void testPrintTransactions() throws AccountholderException {
		
		assertNotNull(c);
	}

}
