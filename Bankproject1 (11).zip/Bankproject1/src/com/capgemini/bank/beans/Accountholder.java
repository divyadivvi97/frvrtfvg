package com.capgemini.bank.beans;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;








import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="accountholder1")
public class Accountholder implements Serializable{
private static final long serialVersionUID = 1L;
@Id	
@GeneratedValue(strategy=GenerationType.IDENTITY)
    private long accountNumber;


@Column(length=30,nullable=false)
	private String accountHolderName;
	private String address;
	
	private int age;
	private String emailId;
	private String adhaarNumber;
	private String mobileNumber;
	private int pinNumber;
	private double balance;
	/*StringBuffer sb= new StringBuffer();*/
	
	@OneToMany(mappedBy="accountholder1",cascade=CascadeType.ALL,fetch=FetchType.EAGER)
	private List<Transaction> transactions = new ArrayList<Transaction>();		
	
	
	public Accountholder() {
		super();
	}
	
	
	public Accountholder(long accountNumber, String accountHolderName, String address, int age,
			String emailId, String adhaarNumber, String mobileNumber, int pinNumber,
			double balance) {
		super();
		this.accountNumber = accountNumber;
		this.accountHolderName = accountHolderName;
		this.address = address;
		this.age = age;
		this.emailId = emailId;
		this.adhaarNumber = adhaarNumber;
		this.mobileNumber = mobileNumber;
		this.pinNumber = pinNumber;
		this.balance = balance;
		/*this.sb = sb;*/
		
	}

	
	public List<Transaction> getTransactions() {
		return transactions;
	}


	public void setTrans(List<Transaction> trans) {
		this.transactions = transactions;
	}


/*	public StringBuffer getSb()
	{
		return sb;
	}
	public void setSb(StringBuffer s)
	{
		this.sb=s;
	}*/
	public String getemailId() {
		return emailId;
	}
	public void setemailId(String emailId) {
		this.emailId = emailId;
	}
	public String getadhaarNumber() {
		return adhaarNumber;
	}
	public void setadhaarNumber(String adhaarNumber) {
		this.adhaarNumber = adhaarNumber;
	}
	public String getmobileNumber() {
		return mobileNumber;
	}
	public void setmobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public int getpinNumber() {
		return pinNumber;
	}
	public void setpinNumber(int pinNumber) {
		this.pinNumber = pinNumber;
	}
	public  double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public long getaccountNumber() {
		return accountNumber;
	}
	public void setaccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getaccountHolderName() {
		return accountHolderName;
	}
	public void setaccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}
	public String getaddress() {
		return address;
	}
	public void setaddress(String address) {
		this.address = address;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	@Override
	public String toString() {
		return "Accountholder [accountNumber=" + accountNumber + ", accountHolderName=" + accountHolderName
				+ ", address=" + address + ", age=" + age + ", emailId=" + emailId
				+ ", adhaarNumber=" + adhaarNumber + ", mobileNumber=" + mobileNumber + ", pinNumber="+ pinNumber + 
				", balance=" + balance + "]";
	}
	
	
	public void addTransaction(Transaction transaction) {
		transaction.setAccountholder1(this);			//this will avoid nested cascade
		this.getTransactions().add(transaction);
	}


	
}
