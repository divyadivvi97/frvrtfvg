package com.capgemini.bank.beans;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;




@Entity
@Table(name="Transaction_table")
public class Transaction implements Serializable{
private static final long serialVersionUID = 1L;
@Id
@GeneratedValue(strategy=GenerationType.IDENTITY)
private int transactionId;
private String transaction;
@ManyToOne
@JoinColumn(name="AccountHolderId")
private Accountholder accountholder1;






public Transaction() {
	
}




public Transaction(int transactionId, String transaction,
		Accountholder accountholder1) {
	super();
	this.transactionId = transactionId;
	this.transaction = transaction;
	this.accountholder1 = accountholder1;
}




public int gettransactionId() {
	return transactionId;
}
public void settransactionId(int transactionId) {
	this.transactionId = transactionId;
}
public String getTransaction() {
	return transaction;
}
public void setTransaction(String transaction) {
	this.transaction = transaction;
}
public Accountholder getAccountholder1() {
	return accountholder1;
}
public void setAccountholder1(Accountholder accountholder1) {
	this.accountholder1 = accountholder1;
}




@Override
public String toString() {
	return "Transaction [transaction=" + transaction + "]";
}








}
