package com.capgemini.bank.dao;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceException;

import com.capgemini.bank.beans.Accountholder;
import com.capgemini.bank.beans.Transaction;
import com.capgemini.bank.exceptions.AccountholderException;
import com.capgemini.bank.utility.JPAUtil;





public class AccountholderDAOImp implements IAccountholderDAO{

	Transaction transaction=new Transaction();

	EntityManagerFactory factory = Persistence.createEntityManagerFactory("Bankproject1");





	public boolean createAccount(Accountholder bean)throws AccountholderException {


		EntityManager em=null;	
		try{

			em=JPAUtil.getEntityManager();


			em.getTransaction().begin();
			bean.setaccountNumber(0);
			em.persist(bean);

			em.getTransaction().commit();
			return em.contains(bean);
		}catch(PersistenceException e) {
			e.printStackTrace();
			throw new AccountholderException(e.getMessage());
		}finally {
			em.close();
		}


	}
	public Accountholder displayAccountholder1(long id3) throws AccountholderException {

		EntityManager em=null;	
		try{

			em=JPAUtil.getEntityManager();

			Accountholder a= em.find(Accountholder.class, id3);
			return a;

		}catch(PersistenceException e) {
			e.printStackTrace();

			throw new AccountholderException(e.getMessage());
		}finally {
			em.close();
		}

	}

	




	public double showBalance(Accountholder m) throws AccountholderException{
		if(m==null)
		{
			return 0;
		}
		return m.getBalance();
		}



	public double deposit(Accountholder e,double amount) throws AccountholderException 
	{
      if(e==null){
	return 0;
       }
		EntityManager em = null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date=new Date();

		try{
			em=JPAUtil.getEntityManager();


			em.getTransaction().begin();
			double bal=0;
			bal=e.getBalance()+amount;
			e.setBalance(bal);


			transaction.setTransaction(" date:  "+dateFormat.format(date)+"  deposit  amount "+amount+"  remaining balance    "+e.getBalance());

			e.addTransaction(transaction);
			em.merge(e);
			em.getTransaction().commit();
			return e.getBalance();
		}catch(PersistenceException e1) {
			e1.printStackTrace();

			throw new AccountholderException(e1.getMessage());
		}finally {
			em.close();
		}
	}

	@Override
	public double withDraw(Accountholder d,double amount2) throws AccountholderException 
	{ 
		 if(d==null){
				return 0;
			       }
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date=new Date();
		double currbal=0;
		EntityManager em=null;	

		try{
			em=JPAUtil.getEntityManager();
			if(d.getBalance()-amount2>500) 
			{
				em.getTransaction().begin();
				currbal=(currbal+d.getBalance()-amount2);
				d.setBalance(currbal);
			transaction.setTransaction(" date:  "+dateFormat.format(date)+"  withdraw amount "+amount2+" remaining balance   "+d.getBalance());

				d.addTransaction(transaction);
				em.merge(d);
				em.getTransaction().commit();
				return currbal;
			}
			else
				return 0;
		}catch(PersistenceException e1) {
			e1.printStackTrace();

			throw new AccountholderException(e1.getMessage());
		}finally {
			em.close();
		}


	}



	@Override
	public int fundTransfer(Accountholder b,Accountholder c, double amount3) throws AccountholderException
	{
		 if(c==null){
				return 0;
			       }
		EntityManager em=null;

		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date=new Date();
		try{
			em=JPAUtil.getEntityManager();


			double currbal1=0;
			double currbal2=0;

			if((amount3<b.getBalance())&&(b.getBalance()-amount3>500))
			{
				em.getTransaction().begin();
				currbal1=(b.getBalance()-amount3);
				b.setBalance(currbal1);
				transaction.setTransaction(" date:  "+dateFormat.format(date)+"  transfer amount   "+amount3+" remaining balance    "+b.getBalance());
				b.addTransaction(transaction);
				em.merge(b);

				currbal2=(c.getBalance()+amount3);
				c.setBalance(currbal2);

				transaction.setTransaction(" date:    "+dateFormat.format(date)+"  received amount  "+amount3+" remaining balance    "+c.getBalance());

				c.addTransaction(transaction);
				em.merge(c);
				em.getTransaction().commit();
			}
			else
				return 0;

			return 1;
		}catch(PersistenceException e1) {
			e1.printStackTrace();

			throw new AccountholderException(e1.getMessage());
		}finally {
			em.close();
		}
	}


	@Override
	public List<Transaction> printTrans(long id7) throws AccountholderException {
		
		EntityManager em=factory.createEntityManager();
		try{
			Accountholder c=em.find(Accountholder.class, id7);
			List<Transaction> passbookList=c.getTransactions();
			return passbookList;

		}catch(PersistenceException e) {
			e.printStackTrace();
			
			throw new AccountholderException(e.getMessage());
		}finally {
			em.close();
		}
	}
	
	

}










