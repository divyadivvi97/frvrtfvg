package com.cap.bank.test;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;

import com.cap.bank.beans.Accountholder1;
import com.cap.bank.beans.Transaction;
import com.cap.bank.exceptions.Accountholder1NotFound;
import com.cap.bank.services.Accountholder1ServicesImp;

public class Testclass extends Accountholder1ServicesImp {
 
	Accountholder1 a= new Accountholder1(1,"divya","Telanagna",45,
			null,"8956859623", "8956985698",51880,
			10000);
	Accountholder1 b= new Accountholder1(2,"bhavani","Telanagna",54,
			"bhavani97@gmail.com","8956895653", "8985962398",518,
			1000);
	
	Accountholder1ServicesImp c = new Accountholder1ServicesImp();
	@Test
	public void testCreateAccount() throws Accountholder1NotFound {
		//assertNotNull(c.createAccount(a));
		a.setEmailid("divyadivvi97@gmail.com");
		boolean b=c.createAccount(a);
		assertTrue(b==true);
	}

	

	@Test
	public void testShowBalance() {
		
		assertEquals(10000, a.getBalance(),0.1);
		//(a.getBalance(), c.showBalance(a));
	}

	@Test
	public void testDeposit() throws Accountholder1NotFound {
		double e=c.deposit(b,1000);
		assertEquals(2000, b.getBalance(),0.1);
		
	}

	@Test
	public void testWithDraw() throws Accountholder1NotFound {
		double withdraw=c.withDraw(b,200);
		assertEquals(800,b.getBalance(),0.1);
		
	}

	
	@Test
	public void testFundTransfer() throws Accountholder1NotFound {
		double a3= c.fundTransfer(a,b,1000);
		assertEquals(9000, a.getBalance(),0.1);
		assertNotEquals(1000,b.getBalance(),0.1);
		
	}

	@Test
	public void testPrintTransactions() throws Accountholder1NotFound {
		
		assertNotNull(c);
	}

}
