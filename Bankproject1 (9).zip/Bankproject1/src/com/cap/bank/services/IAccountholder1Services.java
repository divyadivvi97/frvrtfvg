package com.cap.bank.services;

import java.util.List;

import com.cap.bank.beans.Accountholder1;
import com.cap.bank.exceptions.Accountholder1NotFound;
import com.cap.bank.beans.Transaction;

public interface IAccountholder1Services {
	
	public boolean createAccount(Accountholder1 bean) throws Accountholder1NotFound;

	public double showBalance(Accountholder1 m) throws Accountholder1NotFound;
	
	public boolean valid(long id) throws Accountholder1NotFound;
	
	//public boolean valid(int pin);
	
	public Accountholder1 displayAccountholder1(long id) throws Accountholder1NotFound;
	
	public double  deposit(Accountholder1 e,double amount) throws Accountholder1NotFound;
	
	public double withDraw(Accountholder1 d, double amount) throws Accountholder1NotFound;
	
	public int fundTransfer(Accountholder1 b,Accountholder1 c,double amount) throws Accountholder1NotFound;
	
	//public Accountholder1 printTransactions(Accountholder1 a) throws Accountholder1NotFound;
	
	public List<Transaction> printTrans(long id7) throws Accountholder1NotFound;
}
