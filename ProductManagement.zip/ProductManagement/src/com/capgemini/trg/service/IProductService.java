package com.capgemini.trg.service;

import java.util.ArrayList;

import com.capgemini.trg.entity.Product;

public interface IProductService {
public ArrayList<Product>getAllProducts();

}
