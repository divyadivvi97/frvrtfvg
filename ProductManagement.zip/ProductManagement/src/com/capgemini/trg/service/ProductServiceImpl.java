package com.capgemini.trg.service;

import java.util.ArrayList;

import org.springframework.stereotype.Service;

import com.capgemini.trg.dao.IProductDao;
import com.capgemini.trg.entity.Product;

@Service
public class ProductServiceImpl implements IProductService {
private IProductDao dao;
	@Override
	public ArrayList<Product> getAllProducts() {
		return  dao.getAllProducts();
		
	}

}
