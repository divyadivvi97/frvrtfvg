package com.capgemini.trg.Controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.capgemini.trg.entity.Product;
import com.capgemini.trg.service.IProductService;

@Controller
public class ProductController {
	@Autowired
	private IProductService service;
@RequestMapping("index")
public String getHomePage(Model m)
{
	String message="hello";
	/*m.addAttribute("msg",message);
	return "home";*/
	ArrayList<Product> prodList=service.getAllProducts();
	m.addAttribute("pdtls",prodList);
	return "home1";
}

}
