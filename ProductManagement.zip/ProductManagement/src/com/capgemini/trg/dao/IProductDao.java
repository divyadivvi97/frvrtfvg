package com.capgemini.trg.dao;

import java.util.ArrayList;

import com.capgemini.trg.entity.Product;

public interface IProductDao {
	public ArrayList<Product>getAllProducts();
}
