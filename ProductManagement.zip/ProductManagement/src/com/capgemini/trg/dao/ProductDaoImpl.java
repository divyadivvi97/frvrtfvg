package com.capgemini.trg.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.trg.entity.Product;

@Repository
@Transactional

public class ProductDaoImpl implements IProductDao {
@PersistenceContext
private EntityManager em;
	@Override
	public ArrayList<Product> getAllProducts() {
		Query q=em.createNamedQuery("getAllProductsQry");
			return	(ArrayList<Product>) q.getResultList();
	//ArrayList<Product> alldata=ArrayList<Product>
				
				
	}
	
}
