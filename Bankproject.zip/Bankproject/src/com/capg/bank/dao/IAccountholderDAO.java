package com.capg.bank.dao;

import com.capg.bank.beans.Accountholder;

public interface IAccountholderDAO {
	public boolean addAccountholder(Accountholder a);
	 
	public Accountholder displayAccountholder(long aid);
	
	public boolean createAccount(Accountholder a);
	public boolean showBalance(long accno);
	public void deposit(long accno,double amount);
	public void withDraw(long accno, double amount);
	public void fundTransfer(long accno1,long accno2,double amount);
	public boolean printTransactions(long accno);
	

}
