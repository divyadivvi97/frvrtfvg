package com.capg.bank.dao;

import java.util.ArrayList;
import java.util.List;

import com.capg.bank.beans.Accountholder;

public class AccountholderDAOImp implements IAccountholderDAO{

	static List<Accountholder> acctList =new ArrayList<Accountholder>();
	@Override
	public boolean addAccountholder(Accountholder a) {
		 boolean isAdded=false;
		  
		 isAdded=acctList.add(a);
		 return isAdded;
	}

	@Override
	public Accountholder displayAccountholder(long aid) {
		Accountholder acct=null;
		for(Accountholder a:acctList){
			if(a.getAccno()==aid){
				acct=a;
			}
		}
		return acct;
	}

	@Override
	public boolean createAccount(Accountholder a) {
		
		return false;
	}

	@Override
	public boolean showBalance(long accno) {
		
		return false;
	}

	@Override
	public void deposit(long accno, double amount) {
		
		
	}

	@Override
	public void withDraw(long accno, double amount) {
		
		
	}

	@Override
	public void fundTransfer(long accno1, long accno2, double amount) {
		
		
	}

	@Override
	public boolean printTransactions(long accno) {
	
		return false;
	}
       


}
