package com.capg.bank.beans;

public class Accountholder {
	private long accno;
	private String accName;
	private StringBuffer addr;
	private int age;
	private String emailid;
	private long idProofNo;
	private StringBuffer mobNum;
	private int pin;
	private double balance;
	static int recno=1000;
	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	public long getIdProofNo() {
		return idProofNo;
	}
	public void setIdProofNo(long idProofNo) {
		this.idProofNo = idProofNo;
	}
	public StringBuffer getMobNum() {
		return mobNum;
	}
	public void setMobNum(StringBuffer mobNum) {
		this.mobNum = mobNum;
	}
	public int getPin() {
		return pin;
	}
	public void setPin(int pin) {
		this.pin = pin;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public long getAccno() {
		return accno;
	}
	public void setAccno(long accno) {
		this.accno = accno;
	}
	public String getAccName() {
		return accName;
	}
	public void setAccName(String accName) {
		this.accName = accName;
	}
	public StringBuffer getAddr() {
		return addr;
	}
	public void setAddr(StringBuffer addr) {
		this.addr = addr;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	@Override
	public String toString() {
		return "Accountholder [accno=" + accno + ", accName=" + accName
				+ ", addr=" + addr + ", age=" + age + ", emailid=" + emailid
				+ ", idProofNo=" + idProofNo + ", mobNum=" + mobNum + //", pin="+ pin + 
				", balance=" + balance + "]";
	}

	
	

}
