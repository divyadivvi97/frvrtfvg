package com.capg.bank.exceptions;

public class AccountholderNotFind extends Exception {

}
