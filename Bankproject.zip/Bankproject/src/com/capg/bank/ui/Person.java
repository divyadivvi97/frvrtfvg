package com.capg.bank.ui;

import java.util.Scanner;

import com.capg.bank.beans.Accountholder;
import com.capg.bank.exceptions.AccountholderNotFind;
import com.capg.bank.services.AccountholderServicesImp;


public class Person {


	public static void main(String[] args) {
		// TODO Auto-generated method stub

		AccountholderServicesImp service = new AccountholderServicesImp();
		 long recno=1000;
		while(true)
		{
			System.out.println("Welcome to bank");
			System.out.println("1.Create Account");
			System.out.println("2.Show Balance");
			System.out.println("3.Deposit Amount");
			System.out.println("4.Withdraw Amount");
			System.out.println("5.Fund transfer");
			System.out.println("6 Print Transactions");
			System.out.println("7.Exit");
			
			
			Scanner sc = new Scanner(System.in);
            int choice = sc.nextInt();
			switch (choice)
			{
			
			case 1:  System.out.println("enter  your Name");
			         String accName = sc.next();

			        System.out.println("enter your Address");
			      //  String addr = sc.next();
			        StringBuffer addr= new StringBuffer();
			         addr.append(sc.next());
			         addr.append(sc.next());
			         addr.append(sc.next());
			         addr.append(sc.next());

			         System.out.println("enter your mobile number");
			         //long mobNum = sc.nextLong();
			         StringBuffer mobNum= new StringBuffer();
			         mobNum.append(sc.next());
			         
			         System.out.println("enter your Id Proof Number");
			         long idProofNo = sc.nextLong();
			         
			         System.out.println("enter your Age");
			         int age = sc.nextInt();
			         
			         System.out.println("enter your Email id");
			         String emailid = sc.next();
			         
			         
			         Accountholder bean = new Accountholder();
			         
			         bean.setAccName(accName);
			         bean.setAddr(addr);
			         bean.setAge(age);
			         bean.setEmailid(emailid);
			         bean.setIdProofNo(idProofNo);
			         bean.setMobNum(mobNum);
			        
			         
			         long accno= recno;
			         recno++;
			        bean.setAccno(accno);
			        int pin=(int)(Math.random()*10000);
			        bean.setPin(pin);
			       // System.out.println(pin);
	boolean isAdded = service.addAccountholder(bean);
	boolean isvalid6 = service.validatemobnum(mobNum);
	boolean isvalid7 = service.validateaccName(accName,age);
	if(isAdded && isvalid6 && isvalid7)
	{   int balance=500;
		System.out.println("Created account successfully");
		System.out.println("minimum balance should be 500");
		bean.setBalance(balance);
		System.out.println(bean);
	}
	else{
		System.out.println(" SORRY Account not created,details are not valid");
	}
	break;
	

			case 2:
			System.out.println("Enter your account Number");
	        int id=sc.nextInt();
	boolean valid = service.validateAid(id);
	
	if(valid){
		
		Accountholder a = service.displayAccountholder(id);
		if(a!=null)
		{
			System.out.println(a);
		
		}
		else{
			try
			{
				throw new AccountholderNotFind();
			}catch(AccountholderNotFind e){
				e.printStackTrace();
			}
		}
	double	balance=a.getBalance();
	System.out.println(balance);
		
		
	}
	else{
	System.out.println("enter valid account number");
	}
		break;
		
			case 3:
				System.out.println("Enter your account Number");
			accno=sc.nextInt();
			boolean valid1 = service.validateAid(accno); 
			//boolean valid2=service.validateExistingAid(accno);
			if(valid1)
			{
				System.out.println("enter the amount to be deposited");
				double deposit=sc.nextDouble();
				Accountholder a = service.displayAccountholder(accno);
				double currbal=0;
				currbal=currbal+a.getBalance()+deposit;
				a.setBalance(currbal);
			System.out.println("your current balance is"+a.getBalance());;	
			}
			
			else
			{
				System.out.println("invalid account number");
			}
			break;
			case 4:
				System.out.println("Enter your account Number");
				accno=sc.nextInt();
				boolean valid3 = service.validateAid(accno); 
				
				if(valid3)
				{
					System.out.println("enter the amount to be withdrawn");
					double withdraw=sc.nextDouble();
					
					Accountholder a = service.displayAccountholder(accno);
					
					if((a.getBalance()>withdraw) && (a.getBalance()-withdraw)>500)
					{
						 double currbal=0;
						 currbal=a.getBalance()-withdraw;
						 a.setBalance(currbal);
						 System.out.println("amount withdrawn is"+withdraw);
						 System.out.println("Remaining balance is"+currbal);
					}
					
					else if((a.getBalance()==withdraw))
					{
						System.out.println("minimum balance shd be 500 u cannot withdraw");
					}
					
					else
					{
						System.out.println("Insufficient balance"+a.getBalance());
					}
				}
					
					break;
			
					case 5:
						System.out.println("Enter your account Number");
						int accno1=sc.nextInt();
						boolean valid4 = service.validateAid(accno1); 
						if(valid4)
						{
							System.out.println("enter the account no to transfer amount");	
							int accno2=sc.nextInt();
							boolean valid5 = service.validateAid(accno2); 
							if(valid5)
							{
								System.out.println("enter the amount to transfer");
								double amount=sc.nextDouble();
								Accountholder a = service.displayAccountholder(accno1);
								if(a.getBalance()>amount)
								{
								double currbal=0;
								currbal=a.getBalance()-amount;
								a.setBalance(currbal);
								
								Accountholder b = service.displayAccountholder(accno2);
								currbal=b.getBalance()+amount;
								b.setBalance(currbal);
						
						
								System.out.println("Balance of"+a.getAccno()+"is"+a.getBalance());
								System.out.println("Balance of"+b.getAccno()+"is"+b.getBalance());
								}
								else
								{
									System.out.println("insufficient balance in"+a.getBalance());
								}
								System.out.println("enter valid account number"+a.getAccno());
							
				}
							
	}
						
                       break;
					case 6:
						break;
					case 7:
						System.exit(0);
						break;
					
	}
			
}
}
}