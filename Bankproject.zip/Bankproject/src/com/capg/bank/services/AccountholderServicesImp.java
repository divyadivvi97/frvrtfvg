package com.capg.bank.services;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capg.bank.beans.Accountholder;
import com.capg.bank.dao.AccountholderDAOImp;

public class AccountholderServicesImp implements IAccountholderServices{
 AccountholderDAOImp dao = new AccountholderDAOImp();
	@Override
	
	public boolean addAccountholder(Accountholder a) {
		
		return dao.addAccountholder(a);
	}

	@Override
	public Accountholder displayAccountholder(long accno) {
		
		return dao.displayAccountholder(accno);
	}

	public boolean validateAid(long accno) {
		
		boolean flag =false; 
		if(accno>999){
			flag=true;
		}
	return flag;	
	}
public boolean validatemobnum(StringBuffer mobNum){
	boolean flag= false;

	Pattern pattern=Pattern.compile("[7-9][0-9]{9}");
	Matcher m = pattern.matcher(mobNum);
	if(m.matches())
	{
    flag=true;
    }
return flag;	
}

public boolean validateaccName(String accName,int age) {
	boolean flag= false;
	if((accName.length()>3) && (age>18)){
		flag= true;
	}
	return flag;
}

@Override
public boolean createAccount(Accountholder a) {
	
	return false;
}

@Override
public void showBalance(long accno) {
	
	
}

@Override
public void deposit(long accno, double amount) {
	
	
}

@Override
public void withDraw(long accno, double amount) {
	// TODO Auto-generated method stub
	
}

@Override
public void fundTransfer(long accno1, long accno2, double amount) {
	// TODO Auto-generated method stub
	
}

@Override
public boolean printTransactions(long accno) {
	// TODO Auto-generated method stub
	return false;
}


}	
	

