package com.cap.bank.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.cap.bank.beans.Accountholder1;

public class Testcase {
Accountholder1 a = new Accountholder1();
	@Test
	public void testCreateAccount() {
		
	}

	@Test
	public void testShowBalance() {
		double bal= a.getBalance();
		assertNotNull(a);
	double bal1 =a.getBalance();
		assertNotNull(bal1);
	}

	@Test
	public void testDeposit() {
		
	}

	@Test
	public void testWithDraw() {
		
	}
	@Test
	public void testFundTransfer() {
		
	}
	@Test
	public void testPrintTransactions() {
		
	}

}
