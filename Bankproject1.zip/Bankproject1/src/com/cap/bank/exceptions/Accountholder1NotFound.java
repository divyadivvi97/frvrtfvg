package com.cap.bank.exceptions;

public class Accountholder1NotFound extends Exception {

	public Accountholder1NotFound(String Message)
		{
			super(Message);
		}
	

	}

