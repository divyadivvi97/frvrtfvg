package com.cap.bank.exceptions;

public class Accountholder1NotFind {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
