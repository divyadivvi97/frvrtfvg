package com.cap.bank.dao;

import java.util.HashMap;

import com.cap.bank.beans.Accountholder1;


public class Accountholder1DAOImp implements IAccountholder1DAO{

	HashMap<Long,Accountholder1> acctList = new HashMap<Long,Accountholder1>();
	
	public boolean createAccount(Accountholder1 bean) {
		Long key=bean.getAccno();
		acctList.put(key,bean);
		return acctList.containsValue(bean);
		
	}

	public Accountholder1 showBalance(long id,int pin) {
	Accountholder1 a=null;
	    	for (Accountholder1 a1 : acctList.values()) {
	    		if((a1.getAccno()==id) &&(a1.getPin()==pin))
	    		{
	    			System.out.println("current Balance is "+a1.getBalance());
	    		}
	    		else
	    		{
	    			System.out.println("Invalid details try again");
	    		}
	}
	    	return a;
		}
			public Accountholder1 deposit(long id1,int pin1,double amount) {
				Accountholder1 h=null;
				for (Accountholder1 a1 : acctList.values()) {
		    		if((a1.getAccno()==id1) &&(a1.getPin()==pin1))
		    		{
		    			if(amount>0)
		    			{
		    			double currbal=0;
		              currbal=(currbal+a1.getBalance()+amount);
		             a1.setBalance(currbal);
		              System.out.println("current balance amount is "+currbal);
		    			}
		    			else
		    				System.out.println("enter valid amount");
		    				
		    		}
				}
				return h;
	}
@Override
	public Accountholder1 withDraw(long id2, int pin2,double amount2) {
	Accountholder1 h=null;
	for (Accountholder1 a1 : acctList.values()) {
		if((a1.getAccno()==id2) &&(a1.getPin()==pin2))
		{
			if(a1.getBalance()-amount2>500){
			double currbal=0;
          currbal=(currbal+a1.getBalance()-amount2);
        a1.setBalance(currbal);
          System.out.println("current balance amount is "+currbal);
			}
			else
				System.out.println("insufficient balance");
		}
	}
	return h;
		
	}

	@Override
	public Accountholder1 fundTransfer(long id3,int pin3, long id4, double amount3) {
		Accountholder1 a=null;
		
		for (Accountholder1 a1 : acctList.values()) {
			if((a1.getAccno()==id3)&&(a1.getPin()==pin3))
			{
			         if(amount3<a1.getBalance())
				                  {
				                    double currbal=0;
			                                currbal=(currbal+a1.getBalance()-amount3);
			                                      a1.setBalance(currbal);
			                         System.out.println("current balance of"+id3+ "is" +currbal);
				                    }
	                      
			                      for (Accountholder1 b1 : acctList.values()) {
							
						
				                      if(b1.getAccno()==id4)
			                         {
				                        double currbal=0;
				                        currbal=currbal+b1.getBalance()+amount3;
				                              b1.setBalance(currbal);
				                         System.out.println("current balance of"+id4+ "is" +currbal);
			                            }
			                      }
			System.out.println("enter valid account number and pin ");
		}
			
		}
		return a;
		
	}
	public boolean printTransactions(long accno){
		return false;
		
	}

	
	}

	

