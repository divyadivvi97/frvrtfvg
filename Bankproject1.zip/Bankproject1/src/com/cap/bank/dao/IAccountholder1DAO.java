package com.cap.bank.dao;

import com.cap.bank.beans.Accountholder1;

public interface IAccountholder1DAO  {
	public boolean createAccount(Accountholder1 bean);

	public Accountholder1 showBalance(long id,int pin);
	
	public Accountholder1 deposit(long id,int pin,double amount);
	
	public Accountholder1 withDraw(long id,int pin,double amount);
	
	public  Accountholder1 fundTransfer(long id3,int pin,long id4,double amount);
	
	public boolean printTransactions(long accno);

	

}
