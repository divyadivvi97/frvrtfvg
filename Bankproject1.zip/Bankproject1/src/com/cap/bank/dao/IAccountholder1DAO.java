package com.cap.bank.dao;

import com.cap.bank.beans.Accountholder1;

public interface IAccountholder1DAO  {
	public boolean createAccount(Accountholder1 bean);

	public double showBalance(Accountholder1 m,long id,int pin);
	
	public boolean valid(long id);
	
	public boolean valid(int pin);
	
	public Accountholder1 displayAccountholder1(long id);
	
	public double deposit(Accountholder1 e, long id,int pin,double amount);
	
	public double withDraw(Accountholder1 d,long id,int pin,double amount);
	
	public int fundTransfer(Accountholder1 b,Accountholder1 c,long id3,int pin,long id4,double amount);
	
	public boolean printTransactions(long accno);

	

}
