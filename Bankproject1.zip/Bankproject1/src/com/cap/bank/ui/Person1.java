package com.cap.bank.ui;

import java.util.Scanner;

import com.cap.bank.beans.Accountholder1;
import com.cap.bank.services.Accountholder1ServicesImp;
import com.cap.bank.exceptions.Accountholder1NotFound;


public class Person1 {

	   public static void main(String[] args) throws Accountholder1NotFound {
		
		
          Accountholder1ServicesImp service = new Accountholder1ServicesImp();
         long recno=1000;
		while(true)
		     {
			System.out.println("Welcome to bank");
			System.out.println("1.Create Account");
			System.out.println("2.Show Balance");
			System.out.println("3.Deposit Amount");
			System.out.println("4.Withdraw Amount");
			System.out.println("5.Fund transfer");
			System.out.println("6 Print Transactions");
			System.out.println("7.Exit");
			
			Accountholder1 bean = new Accountholder1();
			@SuppressWarnings("resource")
			Scanner sc = new Scanner(System.in);

			int choice = sc.nextInt();
			switch (choice) {

			
			case 1:  int age; String emailid; String accName;
			         StringBuffer addr ;StringBuffer mobNum; 
			         StringBuffer idProofNo;
				   do{
				      System.out.println("enter  your Name");
			          accName = sc.next();
				     } while(service.validateAccname(accName));
			         
				   do{
			            System.out.println("enter your Address");
			            System.out.println("enter your state");
			            addr = new StringBuffer();
			            addr.append(sc.next());
				   }  while(service.validateAddress(addr));
				   do{
			            System.out.println("enter your city");
			            addr = new StringBuffer();
			            addr.append(sc.next());
				   }  while(service.validateAddress(addr));
				   do{
			            System.out.println("enter your country");
			            addr = new StringBuffer();
			            addr.append(sc.next());
				   }  while(service.validateAddress(addr));
			        		//addr.append(sc.next());
				   
			        		//addr.append(System.lineSeparator());
			        		//addr.append(sc.next());
			        		//addr.append(System.lineSeparator());
			        		
			        		
			        do{		
			        	System.out.println("enter your mobile number");
			            mobNum= new StringBuffer();
			            mobNum.append(sc.next());
			          } while(service.validatemobNum(mobNum));
			         
			         do{
			            System.out.println("enter your Id Proof Number");
			            idProofNo= new StringBuffer();
			        	idProofNo.append(sc.next());
			           } while(service.validateidProof(idProofNo));
			         
			         do{
			            System.out.println("enter your Age");
			            age = sc.nextInt();
			          } while(service.validateAge(age));
			       
		             do{
		        	   System.out.println("enter your Email id");
		               emailid = sc.next();
		               }while(service.validateEmailId(emailid));
			         
			          long accno= recno;
			         
			           bean.setAccno(accno);
			           recno++;
			           bean.setAccName(accName);
			           bean.setAddr(addr);
			           bean.setAge(age);
			           bean.setEmailid(emailid);
			           bean.setIdProofNo(idProofNo);
			           bean.setMobNum(mobNum);
			         
				       int pinno=(int)(Math.random()*100000);
				       bean.setPin(pinno);
			    	   boolean isAdded=service.createAccount(bean);
			    		if(isAdded)
			    		{
			    		double balance=500;
			    		System.out.println("Created account successfully");
			    		System.out.println("minimum balance should be 500");
			    		bean.setBalance(balance);
			    		System.out.println(bean);
			    		
			    	     }
			    	else
			    		System.out.println(" SORRY Account not created");
			
			    	break;
			    	
			case 2:
		           System.out.println("Enter your account Number");
				  long   id=sc.nextLong();
		        	
		        	 boolean val=service.valid(id);
		        	 if(val)
		        	 { 
		        		 System.out.println("enter your pin");
		        	     int pin= sc.nextInt();
		        	    Accountholder1 m = service.displayAccountholder1(id);
		        		 boolean valid1=service.validateAccnoPinno( m,id,pin);
		        		 if(valid1)
		        		 {
		        		 double a= service.showBalance(m);
		        	     System.out.println("your current balance is"+a);
		        		 }
		        	     else
			        	 {
			        		 try{
			        		 throw new Accountholder1NotFound("Account no and pin are not matching");
			        		 }
			        		 catch(Accountholder1NotFound e)
			        		 {
			        			//e.getMessage();
			        			 e.printStackTrace();
			        		 }
			        	 }
		        	    }
		        	  
		        	 else 
		        	 {
		        		 try {
		        			 throw new Accountholder1NotFound("Enter valid account number");
		        		     }
		        		 catch(Accountholder1NotFound e)
		        		 {
		        			e.getMessage();
		        			 //e.printStackTrace();
		        		 }
		        	
		        	
		        	 }
		        	 
		        		  break;
		        	 
		        		  
			case 3:System.out.println("Enter your account Number");
			      long  id1=sc.nextLong();
			 
			      
			      boolean val1=service.valid(id1);
	        	 if(val1)
	        	 {
	        		 System.out.println("enter your pin");
		        	 int pin1= sc.nextInt();
		     
		        	
						Accountholder1 e = service.displayAccountholder1(id1);
						boolean valid10=service.validateAccnoPinno( e,id1,pin1);
		        		 if(valid10)
		        		 {
		        			 System.out.println("enter the amount to be deposited");
		 					 double amount=sc.nextInt();
					         double a1= service.deposit(e,amount);
					         System.out.println("your current balance is"+a1);
		        	      } 
	        	 
		        	 else
	        		 {
	        			 try {
		        			 throw new Accountholder1NotFound("account number and pin are not matched");
		        		     } 
		        		     catch(Accountholder1NotFound e1)
		        		    {
		        		    	 e1.printStackTrace();
		        			 
		        		    } 
	        		 }
	        		 }
	        	 else
	        	 {
	        		 try {
	        			 throw new Accountholder1NotFound("enter valid accountnumber");
	        		     } 
	        		    catch(Accountholder1NotFound e)
	        		      {
	        		    	e.printStackTrace();
	        		       }
	        	
	        		
	        	          }
	        	 
				break;
		    
				
			case 4: 
				    System.out.println("Enter your account Number");
			        long  id2=sc.nextLong();
			        
			        boolean val4=service.valid(id2);
	        	 if(val4)
	        	 {
	        		 System.out.println("enter your pin");
		        	 int pin2= sc.nextInt();
					  Accountholder1 d = service.displayAccountholder1(id2);
					  boolean valid11=service.validateAccnoPinno( d,id2,pin2);
		        		 if(valid11)
		        		 {
		        			 System.out.println("enter the amount to be withdraw");
		   				  double amount2=sc.nextInt();
					  double a2= service.withDraw(d,amount2);
					  System.out.println("your current balance is "+a2);
					          if(a2==0)
					           {
						           try {
		        			 throw new Accountholder1NotFound("insufficient balance");
		        		                  }
						             catch(Accountholder1NotFound e)
						              {
						            	 e.printStackTrace();
		        			          }
						      
					           }
					          }
					   else
				        		 {
				        			 try {
					        			 throw new Accountholder1NotFound("account number and pin are not matched");
					        		     } 
					        		     catch(Accountholder1NotFound e)
					        		    {
					        		    	 e.printStackTrace();
					     
					        		    }
					            } 
		        		 }
	        	 else
	        	 {
	        		 try {
	        			 throw new Accountholder1NotFound("enter valid accountnumber");
	        		        }
	        		     catch(Accountholder1NotFound e)
	        		         {
	        		    	 e.printStackTrace();
	        			      }
	        	  }
		       break;
				
			case 5:  System.out.println("Enter your account Number");
			         long  id3=sc.nextLong();
			         Accountholder1 b = service.displayAccountholder1(id3);
						

			         boolean val6=service.valid(id3);
			      if(val6)
	        	       {
			    	  System.out.println("enter your pin");
			        	 int pin3= sc.nextInt();
			        		 boolean valid12=service.validateAccnoPinno( b,id3,pin3);
			        		 if(valid12)
			        		 {
			        	 System.out.println("Enter account Number you want to transfer");
						  long  id4=sc.nextLong();
						  Accountholder1 c = service.displayAccountholder1(id4);
						  boolean val7=service.valid(id4);
						  if(val7)
				        	 {
							  System.out.println("enter the amount to be transfer");
								double amount3=sc.nextInt();
								int a3= service.fundTransfer(b,c,amount3);
								if(a3==0)
							   {
									try {
					        			 throw new Accountholder1NotFound("Insufficient balance");
					        		 }catch(Accountholder1NotFound e){
					        			 e.printStackTrace();
					        		 }
				        	   }
								else
								{
								   System.out.println("Transaction succesfully completed");
								   System.out.println("remaining balance of Accno: "+id3+" is "+b.getBalance());
								   System.out.println("Updated balance of Accno: "+id4+" is "+c.getBalance());
								 }
				        	 }
						  else
						  { 
							  try {
			        			 throw new Accountholder1NotFound("enter valid accountnumber");
			        		      }
							  catch(Accountholder1NotFound e)
							    {
			        			 e.printStackTrace();
			        		    }
						  }
			        		 }
						  else {
			        			 try {
				        			 throw new Accountholder1NotFound("account number and pin are not matched");
				        		     } 
				        		     catch(Accountholder1NotFound e)
				        		    {
				        		    	 e.printStackTrace();
				        	
				        		    } 
			        		 }
	        	       }
			        		 else
							  { 
								  try {
				        			 throw new Accountholder1NotFound("enter valid accountnumber");
				        		      }
								  catch(Accountholder1NotFound e)
								    {
				        			 e.printStackTrace();
				        		    }
						  }
                       break;
					case 6:
						 System.out.println("enter your account number");
						 long  id7=sc.nextLong();
						 Accountholder1 c = service.displayAccountholder1(id7);
						 boolean val7=service.valid(id7);
						  if(val7)
				        	 {
							  try {
				        			 throw new Accountholder1NotFound("enter valid accountnumber");
				        		   } 
							   catch(Accountholder1NotFound e)
							       {
								   e.printStackTrace();
				        	 }
				        	 }
				        	 else
				        	 {
						     System.out.println("enter your pin");
				        	 int pin3= sc.nextInt();
				        	
				        	 boolean valid13=service.validateAccnoPinno( c,id7,pin3);
			        		 if(valid13)
			        		 {
				        	Accountholder1 a= service.printTrans(id7);
		                      }
			        		 else {
			        			 try {
				        			 throw new Accountholder1NotFound("account number and pin are not matched");
				        		     } 
				        		     catch(Accountholder1NotFound e)
				        		    {
				        		    	 e.printStackTrace();
				        			
				        		 } 
			        		 }
						 	}
			
			}
			}
		
		}
}
