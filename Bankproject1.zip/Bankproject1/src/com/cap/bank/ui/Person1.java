package com.cap.bank.ui;

import java.util.Scanner;

import com.cap.bank.beans.Accountholder1;
import com.cap.bank.services.Accountholder1ServicesImp;
import com.cap.bank.beans.Accountholder1;

public class Person1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
Accountholder1ServicesImp service = new Accountholder1ServicesImp();
		
		while(true)
		{
			System.out.println("Welcome to bank");
			System.out.println("1.Create Account");
			System.out.println("2.Show Balance");
			System.out.println("3.Deposit Amount");
			System.out.println("4.Withdraw Amount");
			System.out.println("5.Fund transfer");
			System.out.println("6 Print Transactions");
			System.out.println("7.Exit");
			
			Accountholder1 bean = new Accountholder1();
			Scanner sc = new Scanner(System.in);

			int choice = sc.nextInt();
			switch (choice) {

			case 1:  System.out.println("enter  your Name");
			         String accName = sc.next();

			        System.out.println("enter your Address");
			        StringBuffer addr = new StringBuffer();
			        		addr.append(sc.next());
			        		addr.append(System.lineSeparator());
			        		addr.append(sc.next());
			        		addr.append(System.lineSeparator());
			        		addr.append(sc.next());

			         System.out.println("enter your mobile number");
			         //long mobNum = sc.nextLong();
			         StringBuffer mobNum= new StringBuffer();
			         mobNum.append(sc.next());
			         
			         System.out.println("enter your Id Proof Number");
			         String idProofNo = sc.next();
			         
			         System.out.println("enter your Age");
			         int age = sc.nextInt();
			       
			         System.out.println("enter your Email id");
			         String emailid = sc.next();
			         
			         
			         
			         
			         bean.setAccName(accName);
			         bean.setAddr(addr);
			         bean.setAge(age);
			         bean.setEmailid(emailid);
			         bean.setIdProofNo(idProofNo);
			         bean.setMobNum(mobNum);
			         long accno=(long)(Math.random()*100000);
				        bean.setAccno(accno);
				      int pinno=(int)(Math.random()*100000);
				        bean.setPin(pinno);
				        
			       
			        boolean isvalid = service.validateCreateAccount(bean);
			    	if(isvalid)
			    	{
			    		boolean isAdded=service.createAccount(bean);
			    		if(isAdded)
			    		{
			    		double balance=500;
			    		System.out.println("Created account successfully");
			    		System.out.println("minimum balance should be 500");
			    		bean.setBalance(balance);
			    		System.out.println(bean);
			    		
			    	}
			    	else
			    		System.out.println(" SORRY Account not created");
			    	}
			    	else
			    	{
			    		System.out.println("SORRY Account not created,details are not valid");
			    	}
			    	break;
			    	
			case 2:
				System.out.println("Enter your account Number");
				  long   id=sc.nextLong();
		        	 System.out.println("enter your pin");
		        	 int pin= sc.nextInt();
		        		  Accountholder1 a= service.showBalance(id,pin);
		        		  break;
		        		  
		        		  
			case 3:System.out.println("Enter your account Number");
			  long  id1=sc.nextLong();
	        	 System.out.println("enter your pin");
	        	 int pin1= sc.nextInt();
	        	 System.out.println("enter the amount to be deposited");
				double amount=sc.nextInt();
				Accountholder1 a1= service.deposit(id1,pin1,amount);
				break;
				
				
			case 4:System.out.println("Enter your account Number");
			  long  id2=sc.nextLong();
	        	 System.out.println("enter your pin");
	        	 int pin2= sc.nextInt();
	        	 System.out.println("enter the amount to be withdraw");
				double amount2=sc.nextInt();
				Accountholder1 a2= service.withDraw(id2,pin2,amount2);
				break;
				
			case 5:System.out.println("Enter your account Number");
			  long  id3=sc.nextLong();
	        	 System.out.println("enter your pin");
	        	 int pin3= sc.nextInt();
	        	 System.out.println("Enter account Number you want to transfer");
				  long  id4=sc.nextLong();
				  System.out.println("enter the amount to be transfer");
					double amount3=sc.nextInt();
					Accountholder1 a3= service.fundTransfer(id3,pin3,id4,amount3);
					break;
		           }
		            }
			}
	

}
