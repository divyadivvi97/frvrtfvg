package com.cap.bank.ui;

import java.util.Scanner;

import com.cap.bank.beans.Accountholder1;
import com.cap.bank.services.Accountholder1ServicesImp;
import com.cap.bank.exceptions.Accountholder1NotFound;


public class Person1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
Accountholder1ServicesImp service = new Accountholder1ServicesImp();
long recno=1000;
		while(true)
		{
			System.out.println("Welcome to bank");
			System.out.println("1.Create Account");
			System.out.println("2.Show Balance");
			System.out.println("3.Deposit Amount");
			System.out.println("4.Withdraw Amount");
			System.out.println("5.Fund transfer");
			System.out.println("6 Print Transactions");
			System.out.println("7.Exit");
			
			Accountholder1 bean = new Accountholder1();
			Scanner sc = new Scanner(System.in);

			int choice = sc.nextInt();
			switch (choice) {

			
			case 1:  int age; String emailid; String accName;StringBuffer addr ;StringBuffer mobNum;StringBuffer idProofNo;
				   do{
				      System.out.println("enter  your Name");
			         accName = sc.next();
				   }while(service.validateAccname(accName));
			         
				   do{
			        System.out.println("enter your Address");
			         addr = new StringBuffer();
			        		//addr.append(sc.next());
			        		//addr.append(System.lineSeparator());
			        		//addr.append(sc.next());
			        		//addr.append(System.lineSeparator());
			        		addr.append(sc.next());
			         }while(service.validateAddress(addr));
			        		
			        do{		
			        	System.out.println("enter your mobile number");
			            mobNum= new StringBuffer();
			            mobNum.append(sc.next());
			          } while(service.validatemobNum(mobNum));
			         
			         do{
			        	 System.out.println("enter your Id Proof Number");
			        	 idProofNo= new StringBuffer();
			        	 idProofNo.append(sc.next());
			           } while(service.validateidProof(idProofNo));
			         
			         do{
			           System.out.println("enter your Age");
			           age = sc.nextInt();
			         } while(service.validateAge(age));
			       
		         do{
		        	 System.out.println("enter your Email id");
		           emailid = sc.next();
		         }while(service.validateEmailId(emailid));
			         
			         long accno= recno;
			         
			         bean.setAccno(accno);
			         recno++;
			         bean.setAccName(accName);
			         bean.setAddr(addr);
			         bean.setAge(age);
			        bean.setEmailid(emailid);
			         bean.setIdProofNo(idProofNo);
			         bean.setMobNum(mobNum);
			         
				      int pinno=(int)(Math.random()*100000);
				        bean.setPin(pinno);
				        
			       
			       // boolean isvalid = service.validateCreateAccount(bean);
			    	//if(isvalid)
			    	//{
			    		boolean isAdded=service.createAccount(bean);
			    		if(isAdded)
			    		{
			    		double balance=500;
			    		System.out.println("Created account successfully");
			    		System.out.println("minimum balance should be 500");
			    		bean.setBalance(balance);
			    		System.out.println(bean);
			    		
			    	}
			    	else
			    		System.out.println(" SORRY Account not created");
			
			    	break;
			    	
			case 2:
				System.out.println("Enter your account Number");
				  long   id=sc.nextLong();
		        	Accountholder1 m = service.displayAccountholder1(id);
		        	 boolean val=service.valid(id);
		        	 if(val)
		        	 {
		        		 System.out.println("enter valid accountnumber");
		        		 System.out.println("  ");
		        	 }
		        	 else
		        	 {
		        	 System.out.println("enter your pin");
		        	 int pin= sc.nextInt();
		        	 boolean val1=service.valid(pin);
		        	 if(val1)
		        	 {
		        		 System.out.println("enter valid pin number");
		        		 System.out.println("  ");
		        	 }
		        	 else
		        	 {
		        		 double a= service.showBalance(m,id,pin);
		        		  if(a==0)
		        			  System.out.println("enter valid details");
		        		  else
		        		  System.out.println("your current balance is"+a);
		        	 }
		        	 }
		        		  break;
		        	 	  
		        		  
			case 3:System.out.println("Enter your account Number");
			  long  id1=sc.nextLong();
			  Accountholder1 e = service.displayAccountholder1(id1);
			  boolean val1=service.valid(id1);
	        	 if(val1)
	        	 {
	        		 System.out.println("enter valid accountnumber");
	        		 System.out.println("  ");
	        	 }
	        	 else
	        	 {
	        	 System.out.println("enter your pin");
	        	 int pin1= sc.nextInt();
	        	 
	        	 System.out.println("enter the amount to be deposited");
				double amount=sc.nextInt();
				double a1= service.deposit(e,id1,pin1,amount);
				if(a1==0)
					try{
						throw new Accountholder1NotFound("enter valid details");
					}catch(Accountholder1NotFound f){
						
					}
					
				else
				System.out.println("your current balance is"+a1);
	        	 }
				break;
				
				
			case 4: 
				System.out.println("Enter your account Number");
			  long  id2=sc.nextLong();
	        	 System.out.println("enter your pin");
	        	 int pin2= sc.nextInt();
	        	 System.out.println("enter the amount to be withdraw");
				double amount2=sc.nextInt();
				Accountholder1 d = service.displayAccountholder1(id2);
				double a2= service.withDraw(d,id2,pin2,amount2);
				if(a2==0)
					System.out.println("enter valid  amount");
				else if(a2==1)
					System.out.println("enter valid details");
				else
					System.out.println("your current balance is "+a2);
				break;
				
			case 5:System.out.println("Enter your account Number");
			  long  id3=sc.nextLong();
	        	 System.out.println("enter your pin");
	        	 int pin3= sc.nextInt();
	        	 System.out.println("Enter account Number you want to transfer");
				  long  id4=sc.nextLong();
				  System.out.println("enter the amount to be transfer");
					double amount3=sc.nextInt();
					Accountholder1 b = service.displayAccountholder1(id3);
					Accountholder1 c = service.displayAccountholder1(id4);
					int a3= service.fundTransfer(b,c,id3,pin3,id4,amount3);
					if(a3==0)
						System.out.println("enter valid amount");
					else if(a3==1)
						System.out.println("enter valid details");
					else{
					System.out.println("reamining balance of Accno: "+id3+" is "+b.getBalance());
					System.out.println("Updated balance of Accno: "+id4+" is "+c.getBalance());
					}
					break;
		           }
		            }
			}
	

}
