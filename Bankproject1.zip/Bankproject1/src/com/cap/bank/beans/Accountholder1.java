package com.cap.bank.beans;

public class Accountholder1 {

    private long accno;
	private String accName;
	private String addr;
	private int age;
	private String emailid;
	private StringBuffer idProofNo;
	private String mobNum;
	private int pin;
	private double balance;
	StringBuffer sb= new StringBuffer();
	public StringBuffer getSb()
	{
		return sb;
	}
	public void setSb(StringBuffer sb)
	{
		this.sb=sb;
	}
	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	public StringBuffer getIdProofNo() {
		return idProofNo;
	}
	public void setIdProofNo(StringBuffer idProofNo) {
		this.idProofNo = idProofNo;
	}
	public String getMobNum() {
		return mobNum;
	}
	public void setMobNum(String mobNum) {
		this.mobNum = mobNum;
	}
	public int getPin() {
		return pin;
	}
	public void setPin(int pin) {
		this.pin = pin;
	}
	public  double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public long getAccno() {
		return accno;
	}
	public void setAccno(long accno) {
		this.accno = accno;
	}
	public String getAccName() {
		return accName;
	}
	public void setAccName(String accName) {
		this.accName = accName;
	}
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	@Override
	public String toString() {
		return "Accountholder [accno=" + accno + ", accName=" + accName
				+ ", addr=" + addr + ", age=" + age + ", emailid=" + emailid
				+ ", idProofNo=" + idProofNo + ", mobNum=" + mobNum + ", pin="+ pin + 
				", balance=" + balance + "]";
	}
	
	
	
	

}
