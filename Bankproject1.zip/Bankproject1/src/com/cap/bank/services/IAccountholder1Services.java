package com.cap.bank.services;

import com.cap.bank.beans.Accountholder1;

public interface IAccountholder1Services {
	
	public boolean createAccount(Accountholder1 bean);

	public Accountholder1 showBalance(long id,int pin);
	
	public Accountholder1  deposit(long accno,int pin,double amount);
	
	public Accountholder1 withDraw(long accno,int pin, double amount);
	
	public Accountholder1 fundTransfer(long accno1,int pin,long accno2,double amount);
	
	public boolean printTransactions(long accno);
}
