package com.cap.bank.services;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cap.bank.beans.Accountholder1;
import com.cap.bank.dao.Accountholder1DAOImp;

public class  Accountholder1ServicesImp implements IAccountholder1Services{
	Accountholder1DAOImp dao= new Accountholder1DAOImp();
	
	public boolean createAccount(Accountholder1 bean)
	{
		return dao.createAccount(bean);
		
	}
	public Accountholder1 displayAccountholder1(long id3) {
		
		return dao.displayAccountholder1(id3);
	}

	public double showBalance(Accountholder1 m,long id,int pin)
	{
		return dao.showBalance(m,id,pin);
		
	}
	public boolean valid(long id)
	{
		return dao.valid(id);
	}
	public boolean valid(int pin)
	{
		return dao.valid(pin);
	}
	
	public double deposit(Accountholder1 e,long id, int pin,double amount)
	{
		return dao.deposit(e,id,pin,amount);
	}
	
	public double withDraw(Accountholder1 d,long id,int pin, double amount)
	{
		return dao.withDraw(d,id,pin,amount);
	}
	
	public int fundTransfer(Accountholder1 b,Accountholder1 c,long id3,int pin3,long id4,double amount){
		return dao.fundTransfer(b,c,id3,pin3,id4,amount);
	}
	
	public boolean printTransactions(long accno){
		return dao.printTransactions(accno);
		
	}
		
	public boolean validateAccno(Accountholder1 bean,long id)
		{boolean flag=false;
		if((bean.getAccno()==id)){
				flag=true;
			}
			return flag;
					}
	public boolean validatepin(Accountholder1 bean,int pin)
	{boolean flag=false;
	if((bean.getPin()==pin)){
			flag=true;
		}
		return flag;
				}
	public boolean validateAccname(String accName){
		boolean flag=true;
		Pattern pattern=Pattern.compile("[A-za-z]*");
		Matcher m = pattern.matcher(accName);
		if((m.matches()) && (accName.length()>2))
		{
			flag=false;
		}
		return flag;
	}
public boolean validateAddress(StringBuffer addr){
	boolean flag=true;
	Pattern pattern=Pattern.compile("[A-Z]{1}[a-z]*");
	Matcher m = pattern.matcher(addr);
	if(m.matches())
	{
	 flag=false;
	}
	return flag;
}
	public boolean validatemobNum(StringBuffer mobNum){
		boolean flag=true;
		Pattern pattern=Pattern.compile("[7-9][0-9]{9}");
		Matcher m = pattern.matcher(mobNum);
		if(m.matches())
		{
		 flag=false;
		}
		return flag;
	}
	public boolean validateidProof(StringBuffer idProofNo){
		boolean flag=true;
		Pattern pattern=Pattern.compile("[0-9][0-9]{9}");
		Matcher m = pattern.matcher(idProofNo);
		if(m.matches())
		{
		 flag=false;
		}
		return flag;
	}
	public boolean validateAge(int age){
		boolean flag=true;
		if(age>18)
		{
			flag=false;
		}
		return flag;
	}
	
	public boolean validateEmailId(String emailid){
		boolean flag=true;
		Pattern pattern=Pattern.compile("[a-zA-Z0-9.]*@[a-zA-Z0-9]+([.][a-zA-z]+)");
		Matcher m = pattern.matcher(emailid);
		if(m.matches())
		{
		 flag=false;
		}
		return flag;
	}
	}

