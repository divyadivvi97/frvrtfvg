package com.cap.bank.services;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cap.bank.beans.Accountholder1;
import com.cap.bank.dao.Accountholder1DAOImp;

public class  Accountholder1ServicesImp implements IAccountholder1Services{
	Accountholder1DAOImp dao= new Accountholder1DAOImp();
	
	public boolean createAccount(Accountholder1 bean)
	{
		return dao.createAccount(bean);
		
	}

	public Accountholder1 showBalance(long id,int pin)
	{
		return dao.showBalance(id, pin);
		
}
	
	public Accountholder1 deposit(long id, int pin,double amount)
	{
		return dao.deposit(id,pin,amount);
	}
	
	public Accountholder1 withDraw(long id,int pin, double amount)
	{
		return dao.withDraw(id,pin,amount);
	}
	
	public Accountholder1 fundTransfer(long id3,int pin3,long id4,double amount){
		return dao.fundTransfer(id3,pin3,id4,amount);
	}
	
	public boolean printTransactions(long accno){
		return dao.printTransactions(accno);
		
	}
		
	public boolean validateCreateAccount(Accountholder1 bean)
		{
			
			boolean flag=false;
			Pattern pattern=Pattern.compile("[7-9][0-9]{9}");
			Matcher m = pattern.matcher(bean.getMobNum());
			Pattern p=Pattern.compile("[0-9][0-9]{9}");
			Matcher n = pattern.matcher(bean.getIdProofNo());
			if((bean.getAccName().length()>3) && (bean.getAge()>18)&& m.matches()&& n.matches()&&(bean.getAccno()>100)){
				flag=true;
			}
			return flag;
			
		}


	

	

	

	}

