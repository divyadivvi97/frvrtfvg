package parallelproject1;

import static org.junit.Assert.*;

import org.junit.Test;

public class BankServicesTest {

	@Test
	public void testCreateAccount() {
		
	}

	@Test
	public void testShowBalance() {
		
	}

	@Test
	public void testDeposit() {
		
	}

	@Test
	public void testWithdraw() {
		
	}

	@Test
	public void testFundTransfer() {
		
	}

	@Test
	public void testPrintTransaction() {
		
	}

}
