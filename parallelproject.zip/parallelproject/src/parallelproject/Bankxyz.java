package parallelproject;

public interface Bankxyz {
 
	public void createAccount();
	
   public void showBalance();
 
   public void deposit();
 
   public void withdraw();
 
   public void fundTransfer();
 
   public void printTransaction();
}
