package features;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.capgemini.project.exam.loan;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefExam {
	private loan loan;
	private WebDriver driver;
	
	/*public void alertMsg() throws InterruptedException {
		String alertMsg=driver.switchTo().alert().getText();
		System.out.println("***********"+alertMsg);
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
	}*/
	
	@Given("^user login is validated and redirected to HTML Form Demo$")
	public void user_login_is_validated_and_redirected_to_HTML_Form_Demo() throws Throwable {
		System.setProperty("webdriver.chrome.driver","G:\\chromedriver.exe");
		driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		loan = new loan(driver);
		driver.get("file:///C:/Users/DIVYA%20BHAVANI-PC/Divyacapg/exam/src/test/java/features/exam.html");
	}

	@Then("^Title is verified$")
	public void title_is_verified() throws Throwable {
		 if(driver.getTitle().contentEquals("HTML Form Demo"))
			   System.out.println("********** Title Matched");
		   else
			   System.out.println("*********** Title mismatch");
		   
		   driver.close();
	}

	@When("^user enters all the valid data$")
	public void user_enters_all_the_valid_data() throws Throwable {
	    loan.setFname("divya");
	    Thread.sleep(1000);
	    loan.setLname("bhavani");
	    loan.setDob("20/03/1997");
	    loan.setFemale();
	    loan.setEnglish();
	    Thread.sleep(1000);
	    loan.setAddress("2-55 dhoolapally");
	    loan.setCity("Delhi");
	    loan.setPhno("9988998877");
	    loan.setAccno("1001");
	    Thread.sleep(1000);
	    loan.setPan("ABCD1234F");
	    loan.setCredit("898765454323");
	    Thread.sleep(1000);
	    loan.setNoofyr("3");
	    loan.setRoi("1");
	    loan.setAmount("2000");
	    loan.setLoantype("Home");
	    Thread.sleep(1000);
	    loan.setEmail("divyadivi97@gmail.com");
	}

	@Then("^navigate to success page$")
	public void navigate_to_success_page() throws Throwable {
		loan.setSubmit();
		    System.out.println("all Valid Credentials");
			driver.navigate().to("file:///C:/Users/DIVYA%20BHAVANI-PC/Divyacapg/exam/src/test/java/features/success.html");
			Thread.sleep(3000);
			System.out.println("loan Confirmed");
			driver.close();
	}

	@When("^user leaves first name blank and clicks the button$")
	public void user_leaves_first_name_blank_and_clicks_the_button() throws Throwable {
		   loan.setFname("");
		   loan.setSubmit();
	    	}

	@Then("^display alert messag$")
	public void display_alert_messag() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();
	}

	@When("^user leaves last name blank and clicks the button$")
	public void user_leaves_last_name_blank_and_clicks_the_button() throws Throwable {
		 loan.setFname("divya");
		 loan.setLname("");
		   loan.setSubmit(); 
	}

	@Then("^display alert message$")
	public void display_alert_message() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();
	}

	@When("^user leaves dateofbirth blank$")
	public void user_leaves_dateofbirth_blank() throws Throwable {
		loan.setFname("divya");
	    Thread.sleep(1000);
	    loan.setLname("bhavani");
	    loan.setDob("");
	    loan.setSubmit();
	   
	}
	
	@Then("^display alert messages$")
	public void display_alert_messages() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();
	}
	@When("^gender is not selected$")
	public void gender_is_not_selected() throws Throwable {
		loan.setFname("divya");
	    Thread.sleep(1000);
	    loan.setLname("bhavani");
	    loan.setDob("20/03/1997");
	    loan.setSubmit();
	}

	@Then("^print error message as select gender$")
	public void print_error_message_as_select_gender() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();
	}

	@When("^languages known is empty$")
	public void languages_known_is_empty() throws Throwable {
		 loan.setFname("divya");
		    Thread.sleep(1000);
		    loan.setLname("bhavani");
		    loan.setDob("20/03/1997");
		    loan.setFemale();
		    loan.setEnglish();
		    Thread.sleep(1000);
		    loan.setSubmit();
	}

	@Then("^print error message as select languages known$")
	public void print_error_message_as_select_languages_known() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();
	    	}

	@When("^address is empty$")
	public void address_is_empty() throws Throwable {
		 loan.setFname("divya");
		    Thread.sleep(1000);
		    loan.setLname("bhavani");
		    loan.setDob("20/03/1997");
		    loan.setFemale();
		    loan.setEnglish();
		    loan.setAddress("");
		    Thread.sleep(1000);
		    loan.setSubmit();
	}

	@Then("^print error message as address is not filled$")
	public void print_error_message_as_address_is_not_filled() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();
	}

	@When("^city is not selected$")
	public void city_is_not_selected() throws Throwable {
		 loan.setFname("divya");
		    Thread.sleep(1000);
		    loan.setLname("bhavani");
		    loan.setDob("20/03/1997");
		    loan.setFemale();
		    loan.setEnglish();
		    Thread.sleep(1000);
		    loan.setAddress("2-55 dhoolapally");
		    loan.setCity("Delhi");
		    loan.setSubmit();
		    
	}

	@Then("^print error message as city is not entered$")
	public void print_error_message_as_city_is_not_entered() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();
	
	}

	@When("^mobileNumber is empty$")
	public void mobilenumber_is_empty() throws Throwable {
		loan.setFname("divya");
	    Thread.sleep(1000);
	    loan.setLname("bhavani");
	    loan.setDob("20/03/1997");
	    loan.setFemale();
	    loan.setEnglish();
	    Thread.sleep(1000);
	    loan.setAddress("2-55 dhoolapally");
	    loan.setCity("Delhi");
	    loan.setPhno("");
		loan.setSubmit();
	}

	@Then("^print error message as enter mobileNumber$")
	public void print_error_message_as_enter_mobileNumber() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();
	
	}

	@When("^AccountNumber is empty$")
	public void accountnumber_is_empty() throws Throwable {
		 loan.setFname("divya");
		    Thread.sleep(1000);
		    loan.setLname("bhavani");
		    loan.setDob("20/03/1997");
		    loan.setFemale();
		    loan.setEnglish();
		    Thread.sleep(1000);
		    loan.setAddress("2-55 dhoolapally");
		    loan.setCity("Delhi");
		    loan.setPhno("9988998877");
		    loan.setAccno("");
		    Thread.sleep(1000);
		loan.setSubmit();
	}

	@Then("^print error message as enter AccountNumber$")
	public void print_error_message_as_enter_AccountNumber() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();
	
	}

	@When("^PanNumber is empty$")
	public void pannumber_is_empty() throws Throwable {
		 loan.setFname("divya");
		    Thread.sleep(1000);
		    loan.setLname("bhavani");
		    loan.setDob("20/03/1997");
		    loan.setFemale();
		    loan.setEnglish();
		    Thread.sleep(1000);
		    loan.setAddress("2-55 dhoolapally");
		    loan.setCity("Delhi");
		    loan.setPhno("9988998877");
		    loan.setAccno("1001");
		    loan.setPan("");
		    Thread.sleep(1000);
		loan.setSubmit();    
	}

	@Then("^print error message as enter PanNumber$")
	public void print_error_message_as_enter_PanNumber() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();
	
	}

	@When("^creditcardNumber is empty$")
	public void creditcardnumber_is_empty() throws Throwable {
		loan.setFname("divya");
	    Thread.sleep(1000);
	    loan.setLname("bhavani");
	    loan.setDob("20/03/1997");
	    loan.setFemale();
	    loan.setEnglish();
	    Thread.sleep(1000);
	    loan.setAddress("2-55 dhoolapally");
	    loan.setCity("Delhi");
	    loan.setPhno("9988998877");
	    loan.setAccno("1001");
	    Thread.sleep(1000);
	    loan.setPan("ABCD1234F");
	    loan.setCredit("");
	    Thread.sleep(1000);
	    
	
		loan.setSubmit();
	}

	@Then("^print error message as enter creditcardnumber$")
	public void print_error_message_as_enter_creditcardnumber() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();
	
	}

	@When("^numberofyears is empty$")
	public void numberofyears_is_empty() throws Throwable {
		loan.setFname("divya");
	    Thread.sleep(1000);
	    loan.setLname("bhavani");
	    loan.setDob("20/03/1997");
	    loan.setFemale();
	    loan.setEnglish();
	    Thread.sleep(1000);
	    loan.setAddress("2-55 dhoolapally");
	    loan.setCity("Delhi");
	    loan.setPhno("9988998877");
	    loan.setAccno("1001");
	    Thread.sleep(1000);
	    loan.setPan("ABCD1234F");
	    loan.setCredit("898765454323");
	    Thread.sleep(1000);
	    loan.setNoofyr("");
	    	loan.setSubmit();
	}

	@Then("^print error message as enter numberofyears$")
	public void print_error_message_as_enter_numberofyears() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();
	
	}

	@When("^rateofinterest is empty$")
	public void rateofinterest_is_empty() throws Throwable {
		loan.setFname("divya");
	    Thread.sleep(1000);
	    loan.setLname("bhavani");
	    loan.setDob("20/03/1997");
	    loan.setFemale();
	    loan.setEnglish();
	    Thread.sleep(1000);
	    loan.setAddress("2-55 dhoolapally");
	    loan.setCity("Delhi");
	    loan.setPhno("9988998877");
	    loan.setAccno("1001");
	    Thread.sleep(1000);
	    loan.setPan("ABCD1234F");
	    loan.setCredit("898765454323");
	    Thread.sleep(1000);
	    loan.setNoofyr("3");
	    loan.setRoi("");
	
		loan.setSubmit(); 
	}

	@Then("^print error message as enter rateofinterest$")
	public void print_error_message_as_enter_rateofinterest() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();
	
	}

	@When("^loanamount is empty$")
	public void loanamount_is_empty() throws Throwable {
		loan.setFname("divya");
	    Thread.sleep(1000);
	    loan.setLname("bhavani");
	    loan.setDob("20/03/1997");
	    loan.setFemale();
	    loan.setEnglish();
	    Thread.sleep(1000);
	    loan.setAddress("2-55 dhoolapally");
	    loan.setCity("Delhi");
	    loan.setPhno("9988998877");
	    loan.setAccno("1001");
	    Thread.sleep(1000);
	    loan.setPan("ABCD1234F");
	    loan.setCredit("898765454323");
	    Thread.sleep(1000);
	    loan.setNoofyr("3");
	    loan.setRoi("1");
	    loan.setAmount("");
	
	    Thread.sleep(1000);
	    
	
		loan.setSubmit(); 
	}

	@Then("^print error message as enter loanamount$")
	public void print_error_message_as_enter_loanamount() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();
	
	    	}

	@When("^loantype is not selected$")
	public void loantype_is_not_selected() throws Throwable {
		loan.setFname("divya");
	    Thread.sleep(1000);
	    loan.setLname("bhavani");
	    loan.setDob("20/03/1997");
	    loan.setFemale();
	    loan.setEnglish();
	    Thread.sleep(1000);
	    loan.setAddress("2-55 dhoolapally");
	    loan.setCity("Delhi");
	    loan.setPhno("9988998877");
	    loan.setAccno("1001");
	    Thread.sleep(1000);
	    loan.setPan("ABCD1234F");
	    loan.setCredit("898765454323");
	    Thread.sleep(1000);
	    loan.setNoofyr("3");
	    loan.setRoi("1");
	    loan.setAmount("2000");
	    loan.setLoantype("");
	    Thread.sleep(1000);
	   loan.setSubmit();
	
	    
	}

	@Then("^print error message as select loantype$")
	public void print_error_message_as_select_loantype() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();
	
	}

	@When("^emailid is empty$")
	public void emailid_is_empty() throws Throwable {
		loan.setFname("divya");
	    Thread.sleep(1000);
	    loan.setLname("bhavani");
	    loan.setDob("20/03/1997");
	    loan.setFemale();
	    loan.setEnglish();
	    Thread.sleep(1000);
	    loan.setAddress("2-55 dhoolapally");
	    loan.setCity("Delhi");
	    loan.setPhno("9988998877");
	    loan.setAccno("1001");
	    Thread.sleep(1000);
	    loan.setPan("ABCD1234F");
	    loan.setCredit("898765454323");
	    Thread.sleep(1000);
	    loan.setNoofyr("3");
	    loan.setRoi("1");
	    loan.setAmount("2000");
	    loan.setLoantype("Home");
	    Thread.sleep(1000);
	    loan.setEmail("");
	
		loan.setSubmit();
	    	}

	@Then("^print error message as enter emailid$")
	public void print_error_message_as_enter_emailid() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();
	
	}


}
