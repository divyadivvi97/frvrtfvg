$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("features/exam.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author:"
    }
  ],
  "line": 2,
  "name": "enter details in loan form",
  "description": "",
  "id": "enter-details-in-loan-form",
  "keyword": "Feature"
});
formatter.background({
  "line": 3,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 4,
  "name": "user login is validated and redirected to HTML Form Demo",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefExam.user_login_is_validated_and_redirected_to_HTML_Form_Demo()"
});
formatter.result({
  "duration": 16575101508,
  "status": "passed"
});
formatter.scenario({
  "line": 7,
  "name": "Verify the title as HTML Form Demo",
  "description": "",
  "id": "enter-details-in-loan-form;verify-the-title-as-html-form-demo",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 8,
  "name": "Title is verified",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefExam.title_is_verified()"
});
formatter.result({
  "duration": 1093270814,
  "status": "passed"
});
formatter.background({
  "line": 3,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 4,
  "name": "user login is validated and redirected to HTML Form Demo",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefExam.user_login_is_validated_and_redirected_to_HTML_Form_Demo()"
});
formatter.result({
  "duration": 7773153356,
  "status": "passed"
});
formatter.scenario({
  "line": 10,
  "name": "Successful login with all valid data",
  "description": "",
  "id": "enter-details-in-loan-form;successful-login-with-all-valid-data",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 11,
  "name": "user enters all the valid data",
  "keyword": "When "
});
formatter.step({
  "line": 12,
  "name": "navigate to success page",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefExam.user_enters_all_the_valid_data()"
});
formatter.result({
  "duration": 10372681945,
  "status": "passed"
});
formatter.match({
  "location": "StepDefExam.navigate_to_success_page()"
});
formatter.result({
  "duration": 8797989958,
  "status": "passed"
});
formatter.background({
  "line": 3,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 4,
  "name": "user login is validated and redirected to HTML Form Demo",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefExam.user_login_is_validated_and_redirected_to_HTML_Form_Demo()"
});
formatter.result({
  "duration": 4037070413,
  "status": "passed"
});
formatter.scenario({
  "line": 14,
  "name": "Failure in loan page on leaving first Name blank",
  "description": "",
  "id": "enter-details-in-loan-form;failure-in-loan-page-on-leaving-first-name-blank",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 15,
  "name": "user leaves first name blank and clicks the button",
  "keyword": "When "
});
formatter.step({
  "line": 16,
  "name": "display alert messag",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefExam.user_leaves_first_name_blank_and_clicks_the_button()"
});
formatter.result({
  "duration": 511694454,
  "status": "passed"
});
formatter.match({
  "location": "StepDefExam.display_alert_messag()"
});
formatter.result({
  "duration": 145755757,
  "error_message": "org.openqa.selenium.NoAlertPresentException: no such alert\n  (Session info: chrome\u003d70.0.3538.110)\n  (Driver info: chromedriver\u003d2.43.600210 (68dcf5eebde37173d4027fa8635e332711d2874a),platform\u003dWindows NT 10.0.17134 x86_64) (WARNING: The server did not provide any stacktrace information)\nCommand duration or timeout: 0 milliseconds\nBuild info: version: \u00273.13.0\u0027, revision: \u00272f0d292\u0027, time: \u00272018-06-25T15:32:19.891Z\u0027\nSystem info: host: \u0027LAPTOP-3G2EQINF\u0027, ip: \u0027192.168.1.106\u0027, os.name: \u0027Windows 10\u0027, os.arch: \u0027amd64\u0027, os.version: \u002710.0\u0027, java.version: \u00271.8.0_191\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities {acceptInsecureCerts: false, acceptSslCerts: false, applicationCacheEnabled: false, browserConnectionEnabled: false, browserName: chrome, chrome: {chromedriverVersion: 2.43.600210 (68dcf5eebde371..., userDataDir: C:\\Users\\DIVYAB~1\\AppData\\L...}, cssSelectorsEnabled: true, databaseEnabled: false, goog:chromeOptions: {debuggerAddress: localhost:59046}, handlesAlerts: true, hasTouchScreen: false, javascriptEnabled: true, locationContextEnabled: true, mobileEmulationEnabled: false, nativeEvents: true, networkConnectionEnabled: false, pageLoadStrategy: normal, platform: XP, platformName: XP, rotatable: false, setWindowRect: true, takesHeapSnapshot: true, takesScreenshot: true, unexpectedAlertBehaviour: , unhandledPromptBehavior: , version: 70.0.3538.110, webStorageEnabled: true}\nSession ID: 572b0418bb3c2d7e99b89b71358d866d\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat java.lang.reflect.Constructor.newInstance(Unknown Source)\r\n\tat org.openqa.selenium.remote.ErrorHandler.createThrowable(ErrorHandler.java:214)\r\n\tat org.openqa.selenium.remote.ErrorHandler.throwIfResponseFailed(ErrorHandler.java:166)\r\n\tat org.openqa.selenium.remote.http.JsonHttpResponseCodec.reconstructValue(JsonHttpResponseCodec.java:40)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:80)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:44)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:158)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:548)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:605)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver$RemoteTargetLocator.alert(RemoteWebDriver.java:928)\r\n\tat com.capgemini.project.exam.StepDefExam.display_alert_messag(StepDefExam.java:87)\r\n\tat ✽.Then display alert messag(features/exam.feature:16)\r\n",
  "status": "failed"
});
formatter.background({
  "line": 3,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 4,
  "name": "user login is validated and redirected to HTML Form Demo",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefExam.user_login_is_validated_and_redirected_to_HTML_Form_Demo()"
});
formatter.result({
  "duration": 13013272497,
  "status": "passed"
});
formatter.scenario({
  "line": 18,
  "name": "Failure in loan page on leaving last Name blank",
  "description": "",
  "id": "enter-details-in-loan-form;failure-in-loan-page-on-leaving-last-name-blank",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 19,
  "name": "user leaves last name blank and clicks the button",
  "keyword": "When "
});
formatter.step({
  "line": 20,
  "name": "display alert message",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefExam.user_leaves_last_name_blank_and_clicks_the_button()"
});
formatter.result({
  "duration": 979659923,
  "status": "passed"
});
formatter.match({
  "location": "StepDefExam.display_alert_message()"
});
formatter.result({
  "duration": 7985668,
  "error_message": "org.openqa.selenium.NoAlertPresentException: no such alert\n  (Session info: chrome\u003d70.0.3538.110)\n  (Driver info: chromedriver\u003d2.43.600210 (68dcf5eebde37173d4027fa8635e332711d2874a),platform\u003dWindows NT 10.0.17134 x86_64) (WARNING: The server did not provide any stacktrace information)\nCommand duration or timeout: 0 milliseconds\nBuild info: version: \u00273.13.0\u0027, revision: \u00272f0d292\u0027, time: \u00272018-06-25T15:32:19.891Z\u0027\nSystem info: host: \u0027LAPTOP-3G2EQINF\u0027, ip: \u0027192.168.1.106\u0027, os.name: \u0027Windows 10\u0027, os.arch: \u0027amd64\u0027, os.version: \u002710.0\u0027, java.version: \u00271.8.0_191\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities {acceptInsecureCerts: false, acceptSslCerts: false, applicationCacheEnabled: false, browserConnectionEnabled: false, browserName: chrome, chrome: {chromedriverVersion: 2.43.600210 (68dcf5eebde371..., userDataDir: C:\\Users\\DIVYAB~1\\AppData\\L...}, cssSelectorsEnabled: true, databaseEnabled: false, goog:chromeOptions: {debuggerAddress: localhost:59058}, handlesAlerts: true, hasTouchScreen: false, javascriptEnabled: true, locationContextEnabled: true, mobileEmulationEnabled: false, nativeEvents: true, networkConnectionEnabled: false, pageLoadStrategy: normal, platform: XP, platformName: XP, rotatable: false, setWindowRect: true, takesHeapSnapshot: true, takesScreenshot: true, unexpectedAlertBehaviour: , unhandledPromptBehavior: , version: 70.0.3538.110, webStorageEnabled: true}\nSession ID: fdc7cba0c435dc99fd438f792fae13be\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat java.lang.reflect.Constructor.newInstance(Unknown Source)\r\n\tat org.openqa.selenium.remote.ErrorHandler.createThrowable(ErrorHandler.java:214)\r\n\tat org.openqa.selenium.remote.ErrorHandler.throwIfResponseFailed(ErrorHandler.java:166)\r\n\tat org.openqa.selenium.remote.http.JsonHttpResponseCodec.reconstructValue(JsonHttpResponseCodec.java:40)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:80)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:44)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:158)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:548)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:605)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver$RemoteTargetLocator.alert(RemoteWebDriver.java:928)\r\n\tat com.capgemini.project.exam.StepDefExam.display_alert_message(StepDefExam.java:104)\r\n\tat ✽.Then display alert message(features/exam.feature:20)\r\n",
  "status": "failed"
});
formatter.background({
  "line": 3,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 4,
  "name": "user login is validated and redirected to HTML Form Demo",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefExam.user_login_is_validated_and_redirected_to_HTML_Form_Demo()"
});
formatter.result({
  "duration": 10423083358,
  "status": "passed"
});
formatter.scenario({
  "line": 22,
  "name": "Failure in loan page on leaving dateofbirth blank",
  "description": "",
  "id": "enter-details-in-loan-form;failure-in-loan-page-on-leaving-dateofbirth-blank",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 23,
  "name": "user leaves dateofbirth blank",
  "keyword": "When "
});
formatter.step({
  "line": 24,
  "name": "display alert messages",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefExam.user_leaves_dateofbirth_blank()"
});
formatter.result({
  "duration": 1937787127,
  "status": "passed"
});
formatter.match({
  "location": "StepDefExam.display_alert_messages()"
});
formatter.result({
  "duration": 19656515,
  "error_message": "org.openqa.selenium.NoAlertPresentException: no such alert\n  (Session info: chrome\u003d70.0.3538.110)\n  (Driver info: chromedriver\u003d2.43.600210 (68dcf5eebde37173d4027fa8635e332711d2874a),platform\u003dWindows NT 10.0.17134 x86_64) (WARNING: The server did not provide any stacktrace information)\nCommand duration or timeout: 0 milliseconds\nBuild info: version: \u00273.13.0\u0027, revision: \u00272f0d292\u0027, time: \u00272018-06-25T15:32:19.891Z\u0027\nSystem info: host: \u0027LAPTOP-3G2EQINF\u0027, ip: \u0027192.168.1.106\u0027, os.name: \u0027Windows 10\u0027, os.arch: \u0027amd64\u0027, os.version: \u002710.0\u0027, java.version: \u00271.8.0_191\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities {acceptInsecureCerts: false, acceptSslCerts: false, applicationCacheEnabled: false, browserConnectionEnabled: false, browserName: chrome, chrome: {chromedriverVersion: 2.43.600210 (68dcf5eebde371..., userDataDir: C:\\Users\\DIVYAB~1\\AppData\\L...}, cssSelectorsEnabled: true, databaseEnabled: false, goog:chromeOptions: {debuggerAddress: localhost:59070}, handlesAlerts: true, hasTouchScreen: false, javascriptEnabled: true, locationContextEnabled: true, mobileEmulationEnabled: false, nativeEvents: true, networkConnectionEnabled: false, pageLoadStrategy: normal, platform: XP, platformName: XP, rotatable: false, setWindowRect: true, takesHeapSnapshot: true, takesScreenshot: true, unexpectedAlertBehaviour: , unhandledPromptBehavior: , version: 70.0.3538.110, webStorageEnabled: true}\nSession ID: 5747fd18dcdcba910f8bb65e9fbe373d\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat java.lang.reflect.Constructor.newInstance(Unknown Source)\r\n\tat org.openqa.selenium.remote.ErrorHandler.createThrowable(ErrorHandler.java:214)\r\n\tat org.openqa.selenium.remote.ErrorHandler.throwIfResponseFailed(ErrorHandler.java:166)\r\n\tat org.openqa.selenium.remote.http.JsonHttpResponseCodec.reconstructValue(JsonHttpResponseCodec.java:40)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:80)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:44)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:158)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:548)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:605)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver$RemoteTargetLocator.alert(RemoteWebDriver.java:928)\r\n\tat com.capgemini.project.exam.StepDefExam.display_alert_messages(StepDefExam.java:124)\r\n\tat ✽.Then display alert messages(features/exam.feature:24)\r\n",
  "status": "failed"
});
formatter.background({
  "line": 3,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 4,
  "name": "user login is validated and redirected to HTML Form Demo",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefExam.user_login_is_validated_and_redirected_to_HTML_Form_Demo()"
});
