$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("features/login.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author:"
    }
  ],
  "line": 2,
  "name": "login application",
  "description": "",
  "id": "login-application",
  "keyword": "Feature"
});
formatter.background({
  "line": 3,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 4,
  "name": "user is on the webpage",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDeflogin.user_is_on_the_webpage()"
});
formatter.result({
  "duration": 3577885264,
  "status": "passed"
});
formatter.scenario({
  "line": 6,
  "name": "verify the title",
  "description": "",
  "id": "login-application;verify-the-title",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 8,
  "name": "check the heading of the page",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDeflogin.check_the_heading_of_the_page()"
});
formatter.result({
  "duration": 8444771208,
  "status": "passed"
});
formatter.background({
  "line": 3,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 4,
  "name": "user is on the webpage",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDeflogin.user_is_on_the_webpage()"
});
formatter.result({
  "duration": 2684972478,
  "status": "passed"
});
formatter.scenario({
  "line": 10,
  "name": "succesfull login with all valid data",
  "description": "",
  "id": "login-application;succesfull-login-with-all-valid-data",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 11,
  "name": "user enter all valid details",
  "keyword": "When "
});
formatter.step({
  "line": 12,
  "name": "navigate to loan page",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDeflogin.user_enter_all_valid_details()"
});
formatter.result({
  "duration": 11799213936,
  "status": "passed"
});
formatter.match({
  "location": "StepDeflogin.navigate_to_loan_page()"
});
formatter.result({
  "duration": 3135028555,
  "status": "passed"
});
formatter.background({
  "line": 3,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 4,
  "name": "user is on the webpage",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDeflogin.user_is_on_the_webpage()"
});
formatter.result({
  "duration": 2758007297,
  "status": "passed"
});
formatter.scenario({
  "line": 14,
  "name": "unsuccesfull login with user name blank",
  "description": "",
  "id": "login-application;unsuccesfull-login-with-user-name-blank",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 15,
  "name": "user leaves username blank and click the button",
  "keyword": "When "
});
formatter.step({
  "line": 16,
  "name": "display appropriate message",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDeflogin.user_leaves_username_blank_and_click_the_button()"
});
formatter.result({
  "duration": 4216682925,
  "status": "passed"
});
formatter.match({
  "location": "StepDeflogin.display_appropriate_message()"
});
formatter.result({
  "duration": 125612766,
  "status": "passed"
});
formatter.background({
  "line": 3,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 4,
  "name": "user is on the webpage",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDeflogin.user_is_on_the_webpage()"
});
formatter.result({
  "duration": 2784443540,
  "status": "passed"
});
formatter.scenario({
  "line": 18,
  "name": "unsuccesfull login with  password  blank",
  "description": "",
  "id": "login-application;unsuccesfull-login-with--password--blank",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 19,
  "name": "user leaves password blank and click the button",
  "keyword": "When "
});
formatter.step({
  "line": 20,
  "name": "display appropriate messages",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDeflogin.user_leaves_password_blank_and_click_the_button()"
});
formatter.result({
  "duration": 4267679473,
  "status": "passed"
});
formatter.match({
  "location": "StepDeflogin.display_appropriate_messages()"
});
formatter.result({
  "duration": 2116318403,
  "status": "passed"
});
formatter.background({
  "line": 3,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 4,
  "name": "user is on the webpage",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDeflogin.user_is_on_the_webpage()"
});
formatter.result({
  "duration": 2675439777,
  "status": "passed"
});
formatter.scenario({
  "line": 22,
  "name": "unsuccesfull login with  incorrect username or password",
  "description": "",
  "id": "login-application;unsuccesfull-login-with--incorrect-username-or-password",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 23,
  "name": "user enters incorrect username or password",
  "keyword": "When "
});
formatter.step({
  "line": 24,
  "name": "display login failed message",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDeflogin.user_enters_incorrect_username_or_password()"
});
formatter.result({
  "duration": 4319331554,
  "status": "passed"
});
formatter.match({
  "location": "StepDeflogin.display_login_failed_message()"
});
formatter.result({
  "duration": 91341724,
  "status": "passed"
});
});