package com.cap.bank.dao;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceException;

import com.cap.bank.beans.Accountholder1;
import com.cap.bank.beans.Transaction;
import com.cap.bank.exceptions.Accountholder1NotFound;
import com.cap.bank.utility.JPAUtil;





public class Accountholder1DAOImp implements IAccountholder1DAO{

	Transaction transaction=new Transaction();

	EntityManagerFactory factory = Persistence.createEntityManagerFactory("Bankproject1");





	public boolean createAccount(Accountholder1 bean)throws Accountholder1NotFound {


		EntityManager em=null;	
		try{

			em=JPAUtil.getEntityManager();


			em.getTransaction().begin();
			bean.setAccno(0);
			em.persist(bean);

			em.getTransaction().commit();
			return em.contains(bean);
		}catch(PersistenceException e) {
			e.printStackTrace();
			throw new Accountholder1NotFound(e.getMessage());
		}finally {
			em.close();
		}


	}
	public Accountholder1 displayAccountholder1(long id3) throws Accountholder1NotFound {

		EntityManager em=null;	
		try{

			em=JPAUtil.getEntityManager();

			Accountholder1 a= em.find(Accountholder1.class, id3);
			return a;

		}catch(PersistenceException e) {
			e.printStackTrace();

			throw new Accountholder1NotFound(e.getMessage());
		}finally {
			em.close();
		}

	}

	public boolean valid(long id3) throws Accountholder1NotFound
	{
		boolean flag=false;

		
		EntityManager em=null;	
		try{

			em=JPAUtil.getEntityManager();

			Accountholder1 a= em.find(Accountholder1.class, id3);
			System.out.println(a);
			if(a.getAccno()==id3)
			{
				flag=true;
			}
			return flag;
		}
		catch(PersistenceException e) {
			e.printStackTrace();

			throw new Accountholder1NotFound(e.getMessage());
		}finally {
			em.close();
		}

	}




	public double showBalance(Accountholder1 m) throws Accountholder1NotFound {

		EntityManager em=null;	
		try{
			em=JPAUtil.getEntityManager();



			Accountholder1 a= em.find(Accountholder1.class,m.getAccno());
			return a.getBalance();
		}catch(PersistenceException e) {
			e.printStackTrace();

			throw new Accountholder1NotFound(e.getMessage());
		}finally {
			em.close();
		}

	}



	public double deposit(Accountholder1 e,double amount) throws Accountholder1NotFound 
	{

		EntityManager em = null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date=new Date();

		try{
			em=JPAUtil.getEntityManager();


			em.getTransaction().begin();
			double bal=0;
			bal=e.getBalance()+amount;
			e.setBalance(bal);

			String c1=("  "+dateFormat.format(date)+"     deposit amount:   "+amount+"          "+bal);
			transaction.setTransaction(c1);

			e.addTransaction(transaction);
			em.merge(e);
			em.getTransaction().commit();
			return e.getBalance();
		}catch(PersistenceException e1) {
			e1.printStackTrace();

			throw new Accountholder1NotFound(e1.getMessage());
		}finally {
			em.close();
		}
	}

	@Override
	public double withDraw(Accountholder1 d,double amount2) throws Accountholder1NotFound 
	{ 
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date=new Date();
		double currbal=0;
		EntityManager em=null;	

		try{
			em=JPAUtil.getEntityManager();
             if(d.getBalance()-amount2>500) 
			{
				em.getTransaction().begin();
				currbal=(currbal+d.getBalance()-amount2);
				d.setBalance(currbal);
				transaction.setTransaction("     "+dateFormat.format(date)+" withdraw amount:    "+amount2+"        "+d.getBalance());

				d.addTransaction(transaction);
				em.merge(d);
				em.getTransaction().commit();
				return currbal;
			}
			else
				return 0;
		}catch(PersistenceException e1) {
			e1.printStackTrace();

			throw new Accountholder1NotFound(e1.getMessage());
		}finally {
			em.close();
		}


	}



	@Override
	public int fundTransfer(Accountholder1 b,Accountholder1 c, double amount3) throws Accountholder1NotFound
	{
		EntityManager em=null;

		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date=new Date();
		try{
			em=JPAUtil.getEntityManager();


			double currbal1=0;
			double currbal2=0;

			if((amount3<b.getBalance())&&(b.getBalance()-amount3>500))
			{
				em.getTransaction().begin();
				currbal1=(currbal1+b.getBalance()-amount3);
				b.setBalance(currbal1);
				transaction.setTransaction("     "+dateFormat.format(date)+"  withdraw amount   "+amount3+"     "+b.getBalance());
				b.addTransaction(transaction);
				em.merge(b);

				currbal2=(currbal2+c.getBalance()+amount3);
				c.setBalance(currbal2);
				String c1="     "+dateFormat.format(date)+"    deposited amount     "+amount3+"      "+c.getBalance();
				transaction.setTransaction(c1);
				c.setBalance(currbal2);
				c.addTransaction(transaction);
				em.merge(c);
				em.getTransaction().commit();
			}
			else
				return 0;

			return 1;
		}catch(PersistenceException e1) {
			e1.printStackTrace();

			throw new Accountholder1NotFound(e1.getMessage());
		}finally {
			em.close();
		}
	}


	@Override
	public List<Transaction> printTrans(long id7) throws Accountholder1NotFound {
		EntityManager em=factory.createEntityManager();
		try{
			Accountholder1 c=em.find(Accountholder1.class, id7);
			List<Transaction> passbookList=c.getTransactions();
			return passbookList;

		}catch(PersistenceException e) {
			e.printStackTrace();
			//TODO: Log to file
			throw new Accountholder1NotFound(e.getMessage());
		}finally {
			em.close();
		}
	}

}










