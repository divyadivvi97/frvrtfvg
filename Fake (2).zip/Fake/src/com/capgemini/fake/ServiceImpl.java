package com.capgemini.fake;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ServiceImpl implements IService{
	@Autowired
	IDao daoObj;

	@Override
	public Cart updateCart(Integer productId, String emailId) {
		// TODO Auto-generated method stub
	return	daoObj.updateCart(productId, emailId);
		
	}

	@Override
	public void removeItemFromTheCart(Integer cartId) {
		// TODO Auto-generated method stub
		daoObj.removeItemFromTheCart(cartId);
	}

	@Override
	public List<Cart> cartDetails(String emailId) {
		// TODO Auto-generated method stub
		return daoObj.cartDetails(emailId);
	}

}
