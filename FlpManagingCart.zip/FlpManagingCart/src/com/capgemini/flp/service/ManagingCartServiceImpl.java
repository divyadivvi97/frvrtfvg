package com.capgemini.flp.service;

import org.springframework.beans.factory.annotation.Autowired;


import com.capgemini.flp.dao.ManagingCartDao;
import com.capgemini.flp.dto.Product;
import com.capgemini.flp.exception.ProductException;

public class ManagingCartServiceImpl implements ManagingCartService{
	@Autowired
	ManagingCartDao Productdao;
	@Override
	public String addProduct(Product product) throws ProductException {
		
		return Productdao.addProduct(product);
	}

	@Override
	public String deleteProduct(Product product) throws ProductException {
		
		return Productdao.deleteProduct(product);
	}

}
