package com.capgemini.flp.service;

import com.capgemini.flp.dto.Product;
import com.capgemini.flp.exception.ProductException;

public interface ManagingCartService {
	public String addProduct(Product product ) throws ProductException;
	public String deleteProduct(Product product ) throws ProductException;
}
