package com.capgemini.flp.dao;


import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;




import org.springframework.stereotype.Repository;

import com.capgemini.flp.dto.Product;
import com.capgemini.flp.exception.ProductException;
@Repository
public class ManagingCartDaoImpl implements ManagingCartDao{
	@PersistenceContext

	EntityManager entityManager;

	@Override
	public String addProduct(Product product) throws ProductException {
		
				
			entityManager.persist(product);
			return "success";
		}

	@Override
	public String deleteProduct(Product product) throws ProductException {
		
		return null;
	}

}
