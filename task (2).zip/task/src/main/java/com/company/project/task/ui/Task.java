package com.company.project.task.ui;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class Task {

	WebDriver wd;

	// initiating Elements
	public Task(WebDriver webdriver) {
		this.wd = webdriver;
		PageFactory.initElements(wd, this);
	}

	@FindBy(how=How.NAME,using="userName")
	@CacheLookup
	WebElement Username;
	
	@FindBy(how=How.NAME,using="city")
	@CacheLookup
	WebElement city;
	
	@FindBy(how=How.NAME,using="password")
	@CacheLookup
	WebElement password;
	
	@FindBy(xpath="/html/body/form/input[6]")
	@CacheLookup
	WebElement female;
	
	@FindBy(xpath="/html/body/form/input[5]")
	@CacheLookup
	WebElement male;
	
	@FindBy(xpath="/html/body/form/input[7]")
	@CacheLookup
	WebElement Eng;
	
	@FindBy(xpath="/html/body/form/input[7]")
	@CacheLookup
	WebElement lang;
	
	@FindBy(xpath="/html/body/form/input[8]")
	@CacheLookup
	WebElement Tel;
	
	@FindBy(xpath="/html/body/form/input[9]")
	@CacheLookup
	WebElement Tam;
	
	@FindBy(xpath="/html/body/form/textarea")
	@CacheLookup
	WebElement hidden;
	/*
	@FindBy(how=How.NAME,using="Country")
	@CacheLookup
	WebElement Country;*/
	
	@FindBy(xpath="/html/body/form/input[11]")
	@CacheLookup
	WebElement MyNumber;
	
	@FindBy(xpath="/html/body/form/input[12]")
	@CacheLookup
	WebElement email;
	
	@FindBy(how=How.NAME,using="mobile")
	@CacheLookup
	WebElement mobile;
	
	@FindBy(how=How.NAME,using="altMobile")
	@CacheLookup
	WebElement altMobile;
	
	@FindBy(xpath="/html/body/center/form/input[17]")
	@CacheLookup
	WebElement jsbutton1stWay;
	
	@FindBy(xpath="/html/body/center/form/button")
	@CacheLookup
	WebElement button;
	
    @FindBy(how=How.NAME,using="saves data")
	@CacheLookup
	WebElement store;
	
	public Task() {
		super();
	}




	public Task(WebElement username, WebElement city, WebElement password, WebElement male,WebElement Tel,WebElement Tam,WebElement lang,WebElement Eng,WebElement female,
			WebElement country, WebElement myNumber, WebElement email, WebElement mobile, WebElement altMobile,
			WebElement store, WebElement jsbutton1stWay, WebElement button,WebElement hidden) {
		super();
		Username = username;
        this.city = city;
		this.password = password;
		this.male = male;
		this.female=female;
		this.lang = lang;
		this.Eng = Eng;
		this.Tel = Tel;
		this.Tam = Tam;
		this.hidden=hidden;
		//Country = country;
		MyNumber = myNumber;
		this.email = email;
		this.mobile = mobile;
		this.altMobile = altMobile;
		this.store = store;
		this.jsbutton1stWay = jsbutton1stWay;
		this.button = button;
	}




	public WebElement getHidden() {
		return hidden;
	}




	public void setHidden(String hidden) {
		this.hidden.sendKeys(hidden);
	}




	public WebElement getUsername() {
		return Username;
	}
	public void setUsername(String Username) {
		this.Username.sendKeys(Username);
	}
	public WebElement getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city.sendKeys(city);
	}
	public WebElement getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password.sendKeys(password);
	}
	public WebElement getMale() {
		return male;
	}
	public void setMale() {
	// this.gender.getAttribute("checked");
		//gender.isSelected();
		male.click();
		
	}
	public WebElement getFemale() {
		return female;
	}
	public void setFemale() {
	// this.gender.getAttribute("checked");
		//gender.isSelected();
		female.click();
		
	}
	public WebElement getEng() {
		return Eng;
	}
	public void setEng() {
		Eng.click();
	}
	/*public WebElement getLang() {
		return lang;
	}
	public void setLang() {
		lang.click();
	}*/
	public WebElement getTel() {
		return Tel;
	}
	public void setTel() {
		Tel.click();
	}
	public WebElement getTam() {
		return Tam;
	}
	public void setTam() {
		Tam.click();
	}
	/*public WebElement getCountry() {
		return Country;
	}
	public void setCountry(WebElement country) {
		Country = country;
	}*/
	public WebElement getMyNumber() {
		return MyNumber;
	}
	public void setMyNumber(String myNumber) {
		MyNumber.sendKeys(myNumber);
	}
	public WebElement getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email.sendKeys(email);
	}
	public WebElement getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile.sendKeys(mobile);
	}
	public WebElement getAltMobile() {
		return altMobile;
	}
	public void setAltMobile(WebElement altMobile) {
		this.altMobile = altMobile;
	}


	public WebElement getJsbutton1stWay() {
		return jsbutton1stWay;
	}


	public void setJsbutton1stWay(WebElement jsbutton1stWay) {
		this.jsbutton1stWay = jsbutton1stWay;
	}


	public WebElement getButton() {
		return button;
	}


	public void setButton() {
		button.click();
	}


	public WebElement getStore() {
		return store;
	}


	public void setStore() {
		store.click();
	}




	


}
