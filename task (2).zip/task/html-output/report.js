$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("features/task.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author:"
    }
  ],
  "line": 2,
  "name": "test the form",
  "description": "",
  "id": "test-the-form",
  "keyword": "Feature"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "check given details",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDeftask.check_given_details()"
});
formatter.result({
  "duration": 7068021367,
  "status": "passed"
});
formatter.scenario({
  "line": 7,
  "name": "",
  "description": "",
  "id": "test-the-form;",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 9,
  "name": "user name is empty",
  "rows": [
    {
      "cells": [
        ""
      ],
      "line": 11
    },
    {
      "cells": [
        "d"
      ],
      "line": 12
    },
    {
      "cells": [
        "1di"
      ],
      "line": 13
    },
    {
      "cells": [
        "div1"
      ],
      "line": 14
    },
    {
      "cells": [
        "divya@"
      ],
      "line": 15
    },
    {
      "cells": [
        "divya"
      ],
      "line": 16
    }
  ],
  "keyword": "When "
});
formatter.step({
  "line": 17,
  "name": "print error message as enter user name",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDeftask.user_name_is_empty(DataTable)"
});
formatter.result({
  "duration": 64353072977,
  "status": "passed"
});
formatter.match({
  "location": "StepDeftask.print_error_message_as_enter_user_name()"
});
formatter.result({
  "duration": 49636,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "check given details",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDeftask.check_given_details()"
});
formatter.result({
  "duration": 2957603249,
  "status": "passed"
});
formatter.scenario({
  "line": 18,
  "name": "",
  "description": "",
  "id": "test-the-form;",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 20,
  "name": "city is empty",
  "keyword": "When "
});
formatter.step({
  "line": 21,
  "name": "print error message as enter city name",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDeftask.city_is_empty()"
});
formatter.result({
  "duration": 190184819,
  "status": "passed"
});
formatter.match({
  "location": "StepDeftask.print_error_message_as_enter_city_name()"
});
formatter.result({
  "duration": 6323726051,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "check given details",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDeftask.check_given_details()"
});
formatter.result({
  "duration": 2870670877,
  "status": "passed"
});
formatter.scenario({
  "line": 23,
  "name": "",
  "description": "",
  "id": "test-the-form;",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 25,
  "name": "password is empty",
  "keyword": "When "
});
formatter.step({
  "line": 26,
  "name": "print error message as enter password",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDeftask.password_is_empty()"
});
formatter.result({
  "duration": 275646564,
  "status": "passed"
});
formatter.match({
  "location": "StepDeftask.print_error_message_as_enter_password()"
});
formatter.result({
  "duration": 6070546663,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "check given details",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDeftask.check_given_details()"
});
formatter.result({
  "duration": 3247739910,
  "status": "passed"
});
formatter.scenario({
  "line": 29,
  "name": "",
  "description": "",
  "id": "test-the-form;",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 31,
  "name": "gender is not selected",
  "keyword": "When "
});
formatter.step({
  "line": 32,
  "name": "print error message as select gender",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDeftask.gender_is_not_selected()"
});
formatter.result({
  "duration": 293782669,
  "status": "passed"
});
formatter.match({
  "location": "StepDeftask.print_error_message_as_select_gender()"
});
formatter.result({
  "duration": 6081663545,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "check given details",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDeftask.check_given_details()"
});
formatter.result({
  "duration": 3033984840,
  "status": "passed"
});
formatter.scenario({
  "line": 34,
  "name": "",
  "description": "",
  "id": "test-the-form;",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 36,
  "name": "languages known is empty",
  "keyword": "When "
});
formatter.step({
  "line": 37,
  "name": "print error message as select languages known",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDeftask.languages_known_is_empty()"
});
formatter.result({
  "duration": 355032584,
  "status": "passed"
});
formatter.match({
  "location": "StepDeftask.print_error_message_as_select_languages_known()"
});
formatter.result({
  "duration": 6060713351,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "check given details",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDeftask.check_given_details()"
});
formatter.result({
  "duration": 3109029944,
  "status": "passed"
});
formatter.scenario({
  "line": 39,
  "name": "",
  "description": "",
  "id": "test-the-form;",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 41,
  "name": "MyNumber is empty",
  "keyword": "When "
});
formatter.step({
  "line": 42,
  "name": "print error message as enter values in MyNumber",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDeftask.mynumber_is_empty()"
});
formatter.result({
  "duration": 571423707,
  "status": "passed"
});
formatter.match({
  "location": "StepDeftask.print_error_message_as_enter_values_in_MyNumber()"
});
formatter.result({
  "duration": 6099384100,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "check given details",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDeftask.check_given_details()"
});
formatter.result({
  "duration": 2885564217,
  "status": "passed"
});
formatter.scenario({
  "line": 44,
  "name": "",
  "description": "",
  "id": "test-the-form;",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 46,
  "name": "email is empty",
  "keyword": "When "
});
formatter.step({
  "line": 47,
  "name": "print error message as enter email",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDeftask.email_is_empty()"
});
formatter.result({
  "duration": 693479682,
  "status": "passed"
});
formatter.match({
  "location": "StepDeftask.print_error_message_as_enter_email()"
});
formatter.result({
  "duration": 6358103878,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "check given details",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDeftask.check_given_details()"
});
formatter.result({
  "duration": 3673069745,
  "status": "passed"
});
formatter.scenario({
  "line": 49,
  "name": "",
  "description": "",
  "id": "test-the-form;",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 51,
  "name": "mobileNumber is empty",
  "keyword": "When "
});
formatter.step({
  "line": 52,
  "name": "print error message as enter mobileNumber",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDeftask.mobilenumber_is_empty()"
});
formatter.result({
  "duration": 785679241,
  "status": "passed"
});
formatter.match({
  "location": "StepDeftask.print_error_message_as_enter_mobileNumber()"
});
formatter.result({
  "duration": 6310745963,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "check given details",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDeftask.check_given_details()"
});
formatter.result({
  "duration": 3001873051,
  "status": "passed"
});
formatter.scenario({
  "line": 54,
  "name": "",
  "description": "",
  "id": "test-the-form;",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 55,
  "name": "all the details are entered",
  "keyword": "When "
});
formatter.step({
  "line": 56,
  "name": "print registration successfully",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDeftask.all_the_details_are_entered()"
});
formatter.result({
  "duration": 691148829,
  "status": "passed"
});
formatter.match({
  "location": "StepDeftask.print_registration_successfully()"
});
formatter.result({
  "duration": 6346459868,
  "status": "passed"
});
});