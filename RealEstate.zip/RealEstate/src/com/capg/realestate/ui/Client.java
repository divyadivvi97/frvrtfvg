package com.capg.realestate.ui;

import java.util.Scanner;

import com.capg.realestate.beans.User;
import com.capg.realestate.exception.OwnerNotFound;
import com.capg.realestate.service.UserServiceImp;

public class Client {

	public static void main(String[] args)  {
		 int ownerId=0;int flatType=0;long flatArea=0;double rentAmount=0;double desiredAmount=0;
		 boolean valid;
		    
		UserServiceImp service= new UserServiceImp();
		while(true)
		{   
			
			System.out.println("1 Register Flat");
		    System.out.println("2 Exit");
		    

			
			Scanner sc= new Scanner(System.in);
            int  choice=sc.nextInt();
            User bean = new User();
             switch(choice)
             {
             case 1:      do {
            	        	 System.out.println("Existing owner Ids are: [1 ,2 ,3]");
     			 System.out.println("please enter your owner id from above list");
     			  ownerId=sc.nextInt();
     			 bean.setOwnerId(ownerId);
     			 
     			 // System.out.println(bean.getOwnerId());
            
            // valid=service.validOwnerId(ownerId);
             if(bean.getOwnerId()==1 || bean.getOwnerId()==2 || bean.getOwnerId()==3)
             {
            	 System.out.println("valid id");
            	 System.out.println("Select FlatType [1-1BHK, 2-2BHK]");
           	  flatType=sc.nextInt();
           	 
          
           	 System.out.println("Enter Flat Area");
           	 flatArea = sc.nextLong();
  
           	 System.out.println("Enter Desired rentAmount");
           	  rentAmount=sc.nextDouble();
           	 do {
            	 System.out.println("Enter Desired Deposit Amount");
                desiredAmount=sc.nextDouble();
             }while(desiredAmount<rentAmount);
                         	 
            	 bean.setFlatType(flatType);
            	 
            	 bean.setFlatArea(flatArea);
            	 
            	
            	 
            	 bean.setRentAmount(rentAmount);
            	 
            	 int flatId=(int)(Math.random()*10000);
			       bean.setFlatId(flatId);
			       
			    boolean isAdded= service.addUser(bean);   
			     if(isAdded)
			     {
			    	 System.out.println("Flat succesfully Registered");
			    	 System.out.println("Registration id is:"+bean.getFlatId());
			    	 System.out.println(bean);
			     }
			     else
			    	 System.out.println("not added");
             }
             
            
            
             
             else
             {
            	 try
            	 {
            		 throw new OwnerNotFound("owner not found.............");
            	 }
             
            	 catch(OwnerNotFound e)
            	 {
            		 System.out.println(e.getMessage());
            	 }
             }
             
             }while(!(bean.getOwnerId()==1)||(bean.getOwnerId()==1)||(bean.getOwnerId()==1));
              
         break;
             case 2:
            	 System.exit(0);
            	 break;
             
             }
		
             }
	}

}

