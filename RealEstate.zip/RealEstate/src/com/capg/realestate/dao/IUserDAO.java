package com.capg.realestate.dao;

import com.capg.realestate.beans.User;

public interface IUserDAO {

	public boolean addUser(User u);
	public User displayUser(int flatId);
public boolean validOwnerId(int ownerId);
	}

