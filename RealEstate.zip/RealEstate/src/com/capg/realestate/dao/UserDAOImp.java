package com.capg.realestate.dao;

import java.util.ArrayList;
import java.util.List;

import com.capg.realestate.beans.User;

public class UserDAOImp implements IUserDAO {
   List <User> uList= new ArrayList<User>();
  
		User b= new User();
	
	@Override
	public boolean addUser(User u) {
		boolean isAdded=false;
		isAdded=uList.add(u);
		return isAdded;
	}

	@Override
	public User displayUser(int flatId) {
		User us= null;
		for(User u:uList)
		{
			if(u.getFlatId()==flatId)
				us=u;
		}
		return us;
	}

	@Override
	public boolean validOwnerId(int ownerId) {
		 
		// TODO Auto-generated method stub
		boolean flag= false;
		for(User u:uList)
		{
			System.out.println(ownerId);
			//a.setOwnerId(ownerId);
			
	if(b.getOwnerId()==ownerId)
	{
		
	 flag=true;
	 b.setOwnerId(ownerId);
	}
		}
		return flag;
	}

	}

	



//	@Override
//	public boolean validOwnerId(User bean) {
//		// TODO Auto-generated method stub
//		return true;
//	}

	
	


