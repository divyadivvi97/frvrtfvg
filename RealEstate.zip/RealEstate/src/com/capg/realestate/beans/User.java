package com.capg.realestate.beans;

public class User {
	private long flatId;
	private int ownerId;
	private int flatType;
	private long flatArea;
	private double rentAmount;
	private double desiredAmount;

	public User()
	{
	}
	public User(long flatId, int ownerId,int flatType,long flatArea,double rentamount,double desiredAmount, double rentAmount)
	{
		this.flatId= flatId;
		this.ownerId=ownerId;
		this.flatType=flatType;
		this.flatArea=flatArea;
		this.rentAmount=rentAmount;
		this.desiredAmount=desiredAmount;
	}
	public long getFlatId() {
		return flatId;
	}
	public void setFlatId(long flatId) {
		this.flatId = flatId;
	}
	public int getOwnerId() {
		return ownerId;
	}
	public void setOwnerId(int ownerId) {
		this.ownerId = ownerId;
	}
	public int getFlatType() {
		return flatType;
	}
	public void setFlatType(int flatType) {
		this.flatType = flatType;
	}
	public long getFlatArea() {
		return flatArea;
	}
	public void setFlatArea(long flatArea) {
		this.flatArea = flatArea;
	}
	public double getRentAmount() {
		return rentAmount;
	}
	public void setRentAmount(double rentAmount) {
		this.rentAmount = rentAmount;
	}
	public double getDesiredAmount() {
		return desiredAmount;
	}
	public void setDesiredAmount(double desiredAmount) {
		this.desiredAmount = desiredAmount;
	}
	@Override
	public String toString() {
		return "User [flatId=" + flatId + ", ownerId=" + ownerId + ", flatType=" + flatType + ", flatArea=" + flatArea
				+ ", rentAmount=" + rentAmount + ", desiredAmount=" + desiredAmount + "]";
	}
	
	}
	

