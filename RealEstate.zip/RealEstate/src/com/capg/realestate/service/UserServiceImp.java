package com.capg.realestate.service;

import com.capg.realestate.beans.User;
import com.capg.realestate.dao.UserDAOImp;

public class UserServiceImp implements IUserService{

	UserDAOImp dao=new UserDAOImp();

	@Override
	public boolean addUser(User u) {
		
		return dao.addUser(u);
	}

	@Override
	public User displayUser(int flatId) {
		
		return dao.displayUser(flatId);
	}
	

public boolean validOwnerId(int ownerId) {
	
		
	
return dao.validOwnerId(ownerId);
		}


}