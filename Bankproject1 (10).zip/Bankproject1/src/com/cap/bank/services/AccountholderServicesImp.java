package com.cap.bank.services;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;

import com.cap.bank.beans.Accountholder;
import com.cap.bank.dao.AccountholderDAOImp;
import com.cap.bank.exceptions.AccountholderException;

import com.cap.bank.utility.JPAUtil;
import com.cap.bank.beans.Transaction;

public class  AccountholderServicesImp implements IAccountholderServices{
	AccountholderDAOImp dao= new AccountholderDAOImp();
	
	public boolean createAccount(Accountholder bean) throws AccountholderException
	{
		return dao.createAccount(bean);
		
	}
	public Accountholder displayAccountholder1(long id3) throws AccountholderException {
		
		return dao.displayAccountholder1(id3);
	}

	public double showBalance(Accountholder m) throws AccountholderException
	{
		return dao.showBalance(m);
		
	}

	public double deposit(Accountholder e,double amount) throws AccountholderException
	{
		return dao.deposit(e,amount);
	}
	
	public double withDraw(Accountholder d,double amount) throws AccountholderException
	{
		return dao.withDraw(d,amount);
	}
	
	public int fundTransfer(Accountholder b,Accountholder c,double amount) throws AccountholderException{
		return dao.fundTransfer(b,c,amount);
	}
	
	public List<Transaction> printTrans(long id7) throws AccountholderException{
		return dao.printTrans(id7);
		
	}

	public boolean valid(long id3) throws AccountholderException
	{
		boolean flag=false;


		EntityManager em=null;	
		try{

			em=JPAUtil.getEntityManager();

			Accountholder a= em.find(Accountholder.class, id3);
			if(a==null){
				return flag;
			}
			else if(a.getAccno()==id3)
			{
				flag=true;
			}
			return flag;
		}
		catch(PersistenceException e) {
			e.printStackTrace();

			throw new AccountholderException(e.getMessage());
		}finally {
			em.close();
		}

	}
	public boolean validateAccnoPinno(Accountholder m,long id,int pin)
	{ 
		boolean flag=false;
	if((m.getAccno()==id)&&(m.getPin()==pin)){
			flag=true;
		}
		return flag;
				}
	public boolean validateAccname(String accName){
		boolean flag=true;
		Pattern pattern=Pattern.compile("[A-za-z]*");
		Matcher m = pattern.matcher(accName);
		if((m.matches()) && (accName.length()>2))
		{
			flag=false;
		}
		return flag;
	}
public boolean validateAddress(String addr){
	boolean flag=true;
	Pattern pattern=Pattern.compile("[A-Z]{1}[a-z]*");
	Matcher m = pattern.matcher(addr);
	if(m.matches())
	{
	 flag=false;
	}
	return flag;
}
	public boolean validatemobNum(String mobNum){
		boolean flag=true;
		Pattern pattern=Pattern.compile("[7-9][0-9]{9}");
		Matcher m = pattern.matcher(mobNum);
		if(m.matches())
		{
		 flag=false;
		}
		return flag;
	}
	public boolean validateidProof(String idProofNo){
		boolean flag=true;
		Pattern pattern=Pattern.compile("[0-9][0-9]{9}");
		Matcher m = pattern.matcher(idProofNo);
		if(m.matches())
		{
		 flag=false;
		}
		return flag;
	}
	public boolean validateAge(int age){
		boolean flag=true;
		if(age>18)
		{
			flag=false;
		}
		return flag;
	}
	
	public boolean validateEmailId(String emailid){
		boolean flag=true;
		Pattern pattern=Pattern.compile("[a-zA-Z0-9.]*@[a-zA-Z0-9]+([.][a-zA-z]+)");
		Matcher m = pattern.matcher(emailid);
		if(m.matches())
		{
		 flag=false;
		}
		return flag;
	}
	
	}

