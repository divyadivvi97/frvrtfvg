package com.cap.bank.dao;

import java.util.List;

import com.cap.bank.beans.Accountholder;
import com.cap.bank.exceptions.AccountholderException;

import com.cap.bank.beans.Transaction;

public interface IAccountholderDAO  {
	public boolean createAccount(Accountholder bean) throws AccountholderException;

	public double showBalance(Accountholder m) throws AccountholderException;
	
	public Accountholder displayAccountholder1(long id) throws AccountholderException;
	
	public double deposit(Accountholder e,double amount) throws AccountholderException;
	
	public double withDraw(Accountholder d,double amount) throws AccountholderException;
	
	public int fundTransfer(Accountholder b,Accountholder c,double amount) throws AccountholderException;
	
	public List<Transaction> printTrans(long id7) throws AccountholderException;
	

}
