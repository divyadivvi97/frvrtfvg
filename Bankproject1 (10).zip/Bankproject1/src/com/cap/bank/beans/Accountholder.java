package com.cap.bank.beans;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;







import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="accountholder1")
public class Accountholder implements Serializable{
private static final long serialVersionUID = 1L;
@Id	
@GeneratedValue(strategy=GenerationType.IDENTITY)
    private long accno;


@Column(length=30,nullable=false)
	private String accName;
	private String addr;
	
	private int age;
	private String emailid;
	private String idProofNo;
	private String mobNum;
	private int pin;
	private double balance;
	/*StringBuffer sb= new StringBuffer();*/
	
	@OneToMany(mappedBy="accountholder1",cascade=CascadeType.ALL,fetch=FetchType.EAGER)
	private List<Transaction> transactions = new ArrayList<Transaction>();		
	
	
	public Accountholder() {
		super();
	}
	
	
	public Accountholder(long accno, String accName, String addr, int age,
			String emailid, String idProofNo, String mobNum, int pin,
			double balance) {
		super();
		this.accno = accno;
		this.accName = accName;
		this.addr = addr;
		this.age = age;
		this.emailid = emailid;
		this.idProofNo = idProofNo;
		this.mobNum = mobNum;
		this.pin = pin;
		this.balance = balance;
		/*this.sb = sb;*/
		
	}

	
	public List<Transaction> getTransactions() {
		return transactions;
	}


	public void setTrans(List<Transaction> trans) {
		this.transactions = transactions;
	}


/*	public StringBuffer getSb()
	{
		return sb;
	}
	public void setSb(StringBuffer s)
	{
		this.sb=s;
	}*/
	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	public String getIdProofNo() {
		return idProofNo;
	}
	public void setIdProofNo(String idProofNo) {
		this.idProofNo = idProofNo;
	}
	public String getMobNum() {
		return mobNum;
	}
	public void setMobNum(String mobNum) {
		this.mobNum = mobNum;
	}
	public int getPin() {
		return pin;
	}
	public void setPin(int pin) {
		this.pin = pin;
	}
	public  double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public long getAccno() {
		return accno;
	}
	public void setAccno(long accno) {
		this.accno = accno;
	}
	public String getAccName() {
		return accName;
	}
	public void setAccName(String accName) {
		this.accName = accName;
	}
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	@Override
	public String toString() {
		return "Accountholder [accno=" + accno + ", accName=" + accName
				+ ", addr=" + addr + ", age=" + age + ", emailid=" + emailid
				+ ", idProofNo=" + idProofNo + ", mobNum=" + mobNum + ", pin="+ pin + 
				", balance=" + balance + "]";
	}
	
	
	public void addTransaction(Transaction transaction) {
		transaction.setAccountholder1(this);			//this will avoid nested cascade
		this.getTransactions().add(transaction);
	}


	
}
