package com.capgemini.doctors.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.dao.DoctorAppointmentDao;
import com.capgemini.doctors.exception.AppointmentIdNotFound;

public class Doctortest {
DoctorAppointmentDao dao = new DoctorAppointmentDao();
	@Test
	public void testAddDoctorAppointmentDetails(DoctorAppointment doctorappointment) {
		DoctorAppointment c= new DoctorAppointment();
		c.setAppointmentId(1000);
		c.setPatientName("Kaira");
		c.setAppointmentStatus(true);
		c.setGender("female");
//		try
//		{
//			dao.addDoctorAppointmentDetails(doctorappointment);
//			boolean c1=dao.addDoctorAppointmentDetails(doctorappointment);
					assertNotNull(c);
//		}
//		finally
//		{
//			System.out.println("executed");
//		}
}

	@Test
	public void testGetDoctorAppointmentDetails(DoctorAppointment doctorappointment,int id) {
		DoctorAppointment b= new DoctorAppointment();
		b.setAppointmentId(0);
		b.setPatientName("Kaira");
		b.setAppointmentStatus(true);
		b.setGender("female");
		try
		{
			dao.addDoctorAppointmentDetails(doctorappointment);
			boolean b1=dao.addDoctorAppointmentDetails(doctorappointment);
					assertNull(b.getAppointmentId());
		}
		finally
		{
			System.out.println("executed");
		}
	}

}
