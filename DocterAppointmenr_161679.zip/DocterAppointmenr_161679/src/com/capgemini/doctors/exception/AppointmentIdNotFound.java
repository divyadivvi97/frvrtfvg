package com.capgemini.doctors.exception;

public class AppointmentIdNotFound extends Exception {
	public  AppointmentIdNotFound(String message)
	{
		super();
	}

}
