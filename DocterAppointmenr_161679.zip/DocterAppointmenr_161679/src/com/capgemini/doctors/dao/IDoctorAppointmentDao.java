package com.capgemini.doctors.dao;

import com.capgemini.doctors.bean.DoctorAppointment;

public interface IDoctorAppointmentDao {
	//public boolean bookAppointment(DoctorAppointment bean) ;
	public boolean valid(int id);
	public boolean isApproved( String ProblemName);
	public int  isAssigned(String ProblemName);
	//public DoctorAppointment viewAppointmentStatus (long id3);
   public boolean addDoctorAppointmentDetails(DoctorAppointment doctorAppointment);
	
	 public DoctorAppointment getDoctorAppointmentDetails(DoctorAppointment doctorAppointment,int id);
}
