package com.capgemini.doctors.dao;

import java.util.HashMap;


import com.capgemini.doctors.bean.DoctorAppointment;

public class DoctorAppointmentDao implements IDoctorAppointmentDao {
	HashMap<Integer,DoctorAppointment> apptList = new HashMap<Integer,DoctorAppointment>();
	
	public boolean valid(int id)
	{ boolean flag=false;
		for ( DoctorAppointment c : apptList.values()) {
		      if(c.getAppointmentId() == id){
		    	 flag=true;
		      }
		      
		   }
		return flag;
	}
	public boolean isApproved(String ProblemName)
	{ boolean a=false;
	
		for ( DoctorAppointment c : apptList.values()) {
		      if(c.getProblemName() == "Heart"||c.getProblemName() == "Gynecology"||c.getProblemName() == "Diabetes"||c.getProblemName() == "ENt"||c.getProblemName() == "Bone" ||c.getProblemName() == "Dermatology"){
		    	 a=true;
		      }
		      
		}  
		return a;
	}
	public int  isAssigned(String ProblemName)
	{
	
		for ( DoctorAppointment c : apptList.values()) {
		      if(c.getProblemName() == "Heart")
		    	  return 0;
		      else if(c.getProblemName() == "Gynecology")
		    	  return 1;
		      else  if(c.getProblemName() == "Diabetes")
		    	  return 2;	  
		      else   if(c.getProblemName() == "Bone")
		    	  return 3;	
		      else if(c.getProblemName() == "Dermatology")
		    	  return 4;	
		      else 
		    	  return 5;
		      
		}
		return 6;
		    		 
		   }
//	public DoctorAppointment viewAppointmentStatus (long id3) {
//		DoctorAppointment cust=null;
//		for (DoctorAppointment c : apptList.values()) {
//      if(c.getAppointmentId() == id3){
//    	cust=c;  
//      }
//      }
//		return cust;
//	}
	@Override
	public boolean addDoctorAppointmentDetails(DoctorAppointment doctorAppointment) {
		Integer key=doctorAppointment.getAppointmentId();
		apptList.put(key,doctorAppointment);
		return apptList.containsValue(doctorAppointment);
		
		
	}
	@Override
	public DoctorAppointment getDoctorAppointmentDetails(
			DoctorAppointment doctorAppointment,int id) {
		DoctorAppointment cust=null;
		for (DoctorAppointment c : apptList.values()) {
      if(c.getAppointmentId() == id){
    	  c.getPatientName();
    	 if( c.getProblemName()=="Heart")
    		 c.setDoctorName("dr.BrijeshKumar");
      
      c.setAppointmentStatus(true);
      
      } 
    	 
    	 
    	cust=c;  
      }
      
		return cust;
		
	}
	
	
//	public DoctorAppointment viewAppointmentStatus( DoctorAppointment bean) {
//       
//		 bean.getAppointmentId();
//		  
	
   }
	


