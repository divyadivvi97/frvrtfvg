package com.capgemini.doctors.service;


import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.dao.DoctorAppointmentDao;



public class DoctorAppointmentService implements IDoctorAppointmentService {
	DoctorAppointmentDao dao= new DoctorAppointmentDao(); 
	
	
	 public boolean addDoctorAppointmentDetails(DoctorAppointment doctorAppointment) {
		return dao.addDoctorAppointmentDetails(doctorAppointment);
	}
	
	 public DoctorAppointment getDoctorAppointmentDetails(DoctorAppointment doctorAppointment,int id)
	{
		return dao.getDoctorAppointmentDetails(doctorAppointment,id);
	}
	 
//	public boolean bookAppointment(DoctorAppointment doctorAppointment) {
//		return dao.bookAppointment(doctorAppointment);
//	}
	public boolean valid(int id){
		return dao.valid(id);
	}
		public boolean isApproved( String ProblemName){
			return dao.isApproved(ProblemName);
		}
		public int  isAssigned(String ProblemName){
			return dao.isAssigned(ProblemName);
		}
//		public DoctorAppointment viewAppointmentStatus (long id3)
//		{
//			return dao.viewAppointmentStatus (id3);
//		}

		
	}

