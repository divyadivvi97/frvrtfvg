package com.capgemini.doctors.service;

import com.capgemini.doctors.bean.DoctorAppointment;

public interface IDoctorAppointmentService {
public 	boolean addDoctorAppointmentDetails(DoctorAppointment doctorAppointment);
	
	 public DoctorAppointment getDoctorAppointmentDetails(DoctorAppointment doctorAppointment,int id);
	//public boolean bookAppointment(DoctorAppointment bean) ;
	
	public boolean valid(int id);
	public boolean isApproved( String ProblemName);
	public int  isAssigned(String ProblemName);
	//public DoctorAppointment viewAppointmentStatus (long id3);
}
