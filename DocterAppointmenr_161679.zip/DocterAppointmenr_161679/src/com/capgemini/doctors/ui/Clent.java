package com.capgemini.doctors.ui;

import java.util.Scanner;





import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.service.DoctorAppointmentService;

public class Clent {                  //class beginns

	public static void main(String[] args) {  //main method
		// TODO Auto-generated method stub
DoctorAppointmentService service = new DoctorAppointmentService(); //object creation
while(true)
{
System.out.println("1)Book Doctor Appointment");
System.out.println("2).View Doctor Appointment");
System.out.println("3)Exit");

DoctorAppointment doctorAppointment = new DoctorAppointment();

Scanner sc = new Scanner(System.in);

int choice = sc.nextInt();
switch (choice) {             //switch begins


case 1: System.out.println("Enter Name of the patient");
         String patientName = sc.next();
         
         System.out.println("Enter Phone Number");
         String phoneNumber = sc.next();
         
         System.out.println("Enter Email");
         String email = sc.next();
         
         System.out.println("Enter Age");
          int age  = sc.nextInt();
          
         System.out.println("Enter Gender");
         String gender = sc.next();
         
         System.out.println("Enter Problem Name");
         String ProblemName  = sc.next();
         
         
         doctorAppointment.setPatientName(patientName);
         doctorAppointment.setPhoneNumber(phoneNumber);
         doctorAppointment.setAge(age);
         doctorAppointment.setEmail(email);
         doctorAppointment.setGender(gender);
         doctorAppointment.setProblemName(ProblemName);
         doctorAppointment.setDoctorName(doctorAppointment.getDoctorName());
	       int appointmentId=(int)(Math.random()*100000);
	       doctorAppointment.setAppointmentId(appointmentId);
	       boolean isAdded=service.addDoctorAppointmentDetails(doctorAppointment);
   		if(isAdded)
   		{
   		
   		System.out.println("Your Doctor Appointment has been successfully registered");
   		System.out.println("Your Appointmnet ID is:"+appointmentId);
   		System.out.println(doctorAppointment);
   		}
   	  
   	break;
   	
   	case 2: System.out.println("Enter the appointmnet Id");
	  int   id=sc.nextInt();
	  boolean val1=service.valid(id);
	 	 
	 	 if(val1)
	 	 { 
	  DoctorAppointment val=service.getDoctorAppointmentDetails(doctorAppointment,id);
	  //System.out.println(val);
	 	
	 		
	  ProblemName= doctorAppointment.getProblemName();
	  
	  boolean appointmentStatus=service.isApproved(ProblemName);
   	  if(appointmentStatus==true)
   	  {
   		//doctorAppointment.setAppointmentStatus();
       	System.out.println("Approved");
   	  }
   		else
   		{
   			//doctorAppointment.setAppointmentStatus(false);
   			System.out.println("disapproved");
   		}
   		
   		int a=service.isAssigned(ProblemName);
   				
   		if(a==0)
   			doctorAppointment.setDoctorName("Dr.Brijesh Kumar");
   		else if(a==1)
   			doctorAppointment.setDoctorName("Dr.Sharda Singh");
   	
   		else if(a==2)
   			doctorAppointment.setDoctorName("Dr.Heena Khan");
   	
   		else if(a==3)
   			doctorAppointment.setDoctorName("Dr.Paras mal");
   	
   		else	if(a==4)
   			doctorAppointment.setDoctorName("Dr.Kanika Kapoor");
   	
   		else
   			doctorAppointment.setDoctorName("null");
   		
   		System.out.println(doctorAppointment.getPatientName());
   		System.out.println(doctorAppointment.getAppointmentStatus());
   		System.out.println(doctorAppointment.getDoctorName());
   	 System.out.println(val);
 		 System.out.println("Appointment date and time, along with doctors phone number will be shared shortly with u");
 	 }
	 	 break;
   		
   	case 3:
		System.exit(0);

		break;
   	
         
}//switch close
	}//while close

}//main close
}//class close