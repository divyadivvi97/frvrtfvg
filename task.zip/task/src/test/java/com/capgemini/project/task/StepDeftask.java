package com.capgemini.project.task;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.function.Predicate;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.company.project.task.ui.Task;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDeftask {

	private Task task;
	private WebDriver driver;
	List<String> li= new ArrayList<String>();
	@Given("^check given details$")
	public void check_given_details() throws Throwable {
		System.setProperty("webdriver.chrome.driver","D:\\chromedriver.exe");
		driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		task = new Task(driver);
		driver.get("file:///D:/myworkspace/task/src/test/java/com/capgemini/project/task/task.html");
 
	}

	@When("^user name is empty$")
	public void user_name_is_empty() throws Throwable {
		//li= arg1.asList(String.class);
		//Predicate<String> p=Pattern.compile("^[a-z]{3,}$").asPredicate();
		// List<String> l = li.stream().filter(p).collect(Collectors.<String>toList());
		// l.forEach(System.out::println);
		 
		 /* for(int i=0;i<=li.size();i++)
		   {
			  System.setProperty("webdriver.chrome.driver","D:\\chromedriver.exe");
				driver = new ChromeDriver();
		        driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
				task = new Task(driver);
				driver.get("file:///D:/myworkspace/task/src/test/java/com/capgemini/project/task/task.html");
			  task.setUsername(li.get(i));
			  task.setStore();
			  String alertMessage = driver.switchTo().alert().getText();
				Thread.sleep(2000);
				driver.switchTo().alert().accept();
				System.out.println("alert :: "+alertMessage);
				Thread.sleep(2000);
				driver.close();
		   }*/
		task.setUsername("");
		task.setStore();
	}

	@Then("^print error message as enter user name$")
	public void print_error_message_as_enter_user_name() throws Throwable {
		 String alertMessage = driver.switchTo().alert().getText();
			Thread.sleep(2000);
			driver.switchTo().alert().accept();
			System.out.println("alert :: "+alertMessage);
			Thread.sleep(2000);
			driver.close();	
	}

	@When("^city is empty$")
	public void city_is_empty() throws Throwable {
		task.setUsername("di");
		task.setCity("");
		task.setStore();
	}

	@Then("^print error message as enter city name$")
	public void print_error_message_as_enter_city_name() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();
	}

	@When("^password is empty$")
	public void password_is_empty() throws Throwable {
		task.setUsername("arvind");
		task.setCity("hyderbad");
		task.setPassword("");
		task.setStore();
	}

	@Then("^print error message as enter password$")
	public void print_error_message_as_enter_password() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();
	}

	@When("^gender is not selected$")
	public void gender_is_not_selected() throws Throwable {
		task.setUsername("arvind");
		task.setCity("hyderbad");
		task.setPassword("Divya123$");
		task.setStore();
	}

	@Then("^print error message as select gender$")
	public void print_error_message_as_select_gender() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();
	}

	@When("^languages known is empty$")
	public void languages_known_is_empty() throws Throwable {
		task.setUsername("arvind");
		task.setCity("hyderbad");
		task.setPassword("Divya123_");
		task.setFemale();
		task.setStore();
	}

	@Then("^print error message as select languages known$")
	public void print_error_message_as_select_languages_known() throws Throwable {

		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();  
	}
	
	@When("^MyNumber is empty$")
	public void mynumber_is_empty() throws Throwable {
		task.setUsername("arvind");
		task.setCity("hyderbad");
		task.setPassword("Divya123#");
		task.setMale();
		task.setTel();
       task.setTam();
		task.setMyNumber("");
		task.setStore(); 
	}

	@Then("^print error message as enter values in MyNumber$")
	public void print_error_message_as_enter_values_in_MyNumber() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close(); 
	}

	@When("^email is empty$")
	public void email_is_empty() throws Throwable {
		task.setUsername("arvind");
		task.setCity("hyderbad");
		task.setPassword("Divya123@");
		task.setMale();
		task.setTel();
		task.setEng();
		task.setTam();
		task.setMyNumber("20");
		task.setEmail("");
		task.setStore(); 
	}

	@Then("^print error message as enter email$")
	public void print_error_message_as_enter_email() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close(); 
	}
	@When("^mobileNumber is empty$")
	public void mobilenumber_is_empty() throws Throwable {
		task.setUsername("aravind");
		task.setCity("hyderbad");
		task.setPassword("Divya123!");
		task.setMale();
		task.setTel();
		task.setEng();
		task.setTam();
		task.setMyNumber("20");
		task.setEmail("divyadivvi@gmail.com");
		task.setMobile("");
		task.setStore(); 
	}

	@Then("^print error message as enter mobileNumber$")
	public void print_error_message_as_enter_mobileNumber() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close(); 
	}
	@When("^all the details are entered$")
	public void all_the_details_are_entered() throws Throwable {
		task.setUsername("aravind");
		task.setCity("hyderbad");
		task.setPassword("Divya123$");
		task.setMale();
		task.setTel();
		task.setEng();
		task.setMyNumber("50");
		task.setEmail("divyadivvi97@gmail.com");
		task.setMobile("9876765645");
		task.setStore(); 
	}
	@Then("^print registration successfully$")
	public void print_registration_successfully() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close(); 
	}
}
