package com.capgemini.employeeapp.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;



import com.capgemini.employeeapp.dto.Product;
import com.capgemini.employeeapp.exception.ProductException;
@Repository
public class CartDaoImpl implements CartDao {
	@PersistenceContext

	EntityManager entityManager;
	@Override
	public List<Product> getProduct() throws ProductException {
		try{
			TypedQuery<Product> query=entityManager.createQuery("from Product",Product.class);
			return query.getResultList();
			}
			catch(Exception e)
			{
				throw new ProductException(e.getMessage());
			}
	
	}
	@Override
	public String addProduct(Product product) throws ProductException {
		
		entityManager.persist(product);
		return "cart";
	}
	@Override
	public Product getProductDetails(int id) throws ProductException {
		try{
			TypedQuery<Product> query=entityManager.createQuery("select pro from Product pro where pro.productId='"+id+"'",Product.class);
			return query.getSingleResult();
			}
			catch(Exception e)
			{
				throw new ProductException(e.getMessage());
			}
	}

}
