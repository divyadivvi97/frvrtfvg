package com.capgemini.employeeapp.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.employeeapp.dto.Product;
import com.capgemini.employeeapp.exception.ProductException;
import com.capgemini.employeeapp.service.CartService;

@Controller
public class CartController {
	@Autowired
	CartService cartservice;
	@RequestMapping("/")
	public ModelAndView showIndex()
	{
		ModelAndView mv= new ModelAndView("index1");
		try {
			List<Product> products=cartservice.getProduct();
			mv.addObject("products", products);
		} catch (ProductException e) {
			
			e.printStackTrace();
		}
		return mv;
	}
	@RequestMapping("/addProduct")
	public String showAdd(Model model)
	{
		model.addAttribute("product", new Product());
		return "add";
	}
	@RequestMapping("/add")
	public  ModelAndView addEmployee(@RequestParam(value="name") int id)
	{  
		ModelAndView mv=new ModelAndView("add");
		try {
			 Product pro=cartservice.getProductDetails(id);
			 mv.addObject("product",pro);
		} catch (ProductException e) {
			System.out.println(e.getMessage());
			
		}
		return mv;
	}


	@RequestMapping(value="Success")
	public ModelAndView dispPurchase(@RequestParam("sessName") String sn){
		
		System.out.println(sn);			//to check whether String is obtained or not. it displays String in console	
		
		return new ModelAndView("success", "data",sn);
	}
}

