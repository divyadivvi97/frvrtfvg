/*package com.capgemini.employeeapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.employeeapp.dao.EmployeeDao;
import com.capgemini.employeeapp.dto.Employee;
import com.capgemini.employeeapp.exception.EmployeeException;
@Transactional
@Service
public class EmployeeServiceImpl implements EmployeeService {
	
	
	@Autowired
	EmployeeDao employeedao;
	@Override
	public List<Employee> getEmployees() throws EmployeeException {
		
		return employeedao.getEmployees() ;
	}
	@Override
	public String addEmployee( Employee employee)
			throws EmployeeException {
		
		return employeedao.addEmployee(employee);
	}

}
*/