package com.capgemini.employeeapp.service;

import java.util.List;

import com.capgemini.employeeapp.dto.Product;
import com.capgemini.employeeapp.exception.ProductException;

public interface CartService {
	List<Product>getProduct() throws ProductException;
	public String addProduct(Product product ) throws ProductException;
	public Product getProductDetails(int id) throws ProductException;
}
