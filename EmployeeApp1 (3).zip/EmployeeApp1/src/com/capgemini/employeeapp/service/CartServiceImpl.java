package com.capgemini.employeeapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.employeeapp.dao.CartDao;
import com.capgemini.employeeapp.dto.Product;
import com.capgemini.employeeapp.exception.ProductException;
@Transactional
@Service
public class CartServiceImpl implements CartService {
	@Autowired
	CartDao cartdao;
	@Override
	public List<Product> getProduct() throws ProductException {
		
		return cartdao.getProduct() ;
	}
	@Override
	public String addProduct(Product product) throws ProductException {
		
		return  cartdao.addProduct(product);
	}
	@Override
	public Product getProductDetails(int id) throws ProductException {
		return cartdao.getProductDetails(id);
	}
	
}
