/*package com.capgemini.employeeapp.dto;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;
@Entity
@Table(name="emp")
public class Employee {
	@Id	
private int empId;
	@NotEmpty(message="Employee Name is Mandatory")
	@Pattern(regexp="[A-za-z\\s]+",message="Name should contain only alaphabets")
private String name;
private String gender;
@Max(60)
@Min(18)
private String age;
private double salary;


public int getEmpId() {
	return empId;
}
public void setEmpId(int empId) {
	this.empId = empId;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}

public String getAge() {
	return age;
}
public void setAge(String age) {
	this.age = age;
}
public double getSalary() {
	return salary;
}
public void setSalary(double salary) {
	this.salary = salary;
}

}
*/