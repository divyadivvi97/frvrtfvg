package com.cg.rest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.rest.dto.Employee;
import com.cg.rest.service.EmployeeService;

@RestController
@RequestMapping("/rest")

public class EmployeeController {
	
	@Autowired
	EmployeeService employeeservice;
	
@RequestMapping("/hi")
public String helo()
{
	return "hi";
}

@RequestMapping("/employees")
public List<Employee> getEmployees(){
	return employeeservice.getEmployees();
	
}
@RequestMapping("/employees/{id}")
public Employee getEmployeeById(@PathVariable int id)
{
	return employeeservice.getEmployeeById(id);
}
@RequestMapping(method=RequestMethod.POST,value="/employees")
public void addEmployee(@RequestBody Employee emp)
{
	employeeservice.addEmployee(emp);
}

@RequestMapping(method=RequestMethod.PUT,value="/employees/{id}")
public void updateEmployee(@RequestBody Employee emp,@PathVariable int id)
{
	employeeservice.updateEmployee(emp,id);
}
@RequestMapping(method=RequestMethod.DELETE,value="/employees/{id}")
public void deleteEmployee(int id)
{
	employeeservice.deleteEmployee(id);
}
}
