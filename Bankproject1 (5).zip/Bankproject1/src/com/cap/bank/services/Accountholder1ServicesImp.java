package com.cap.bank.services;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cap.bank.beans.Accountholder1;
import com.cap.bank.dao.Accountholder1DAOImp;
import com.cap.bank.exceptions.Accountholder1NotFound;

public class  Accountholder1ServicesImp implements IAccountholder1Services{
	Accountholder1DAOImp dao= new Accountholder1DAOImp();
	
	public boolean createAccount(Accountholder1 bean) throws Accountholder1NotFound
	{
		return dao.createAccount(bean);
		
	}
	public Accountholder1 displayAccountholder1(long id3) throws Accountholder1NotFound {
		
		return dao.displayAccountholder1(id3);
	}

	public double showBalance(Accountholder1 m) throws Accountholder1NotFound
	{
		return dao.showBalance(m);
		
	}
	public boolean valid(long id) throws Accountholder1NotFound
	{
		return dao.valid(id);
	}
//	public boolean valid(int pin)
//	{
//		return dao.valid(pin);
//	}
	
	public double deposit(Accountholder1 e,double amount) throws Accountholder1NotFound
	{
		return dao.deposit(e,amount);
	}
	
	public double withDraw(Accountholder1 d,double amount) throws Accountholder1NotFound
	{
		return dao.withDraw(d,amount);
	}
	
	public int fundTransfer(Accountholder1 b,Accountholder1 c,double amount) throws Accountholder1NotFound{
		return dao.fundTransfer(b,c,amount);
	}
	
	public Accountholder1 printTrans(long id7) throws Accountholder1NotFound{
		return dao.printTrans(id7);
		
	}

	public Accountholder1 printTransactions(Accountholder1 a) throws Accountholder1NotFound{
		return dao.printTransactions(a);
		
	}
		
//	public boolean validateAccno(Accountholder1 bean,long id)
//		{boolean flag=false;
//		if((bean.getAccno()==id)){
//				flag=true;
//			}
//			return flag;
		
	//				}
//	public boolean validatepin(Accountholder1 bean,int pin)
//	{boolean flag=false;
//	if((bean.getPin()==pin)){
//			flag=true;
//		}
//		return flag;
//				}
	public boolean validateAccnoPinno(Accountholder1 m,long id,int pin)
	{ 
		boolean flag=false;
	if((m.getAccno()==id)&&(m.getPin()==pin)){
			flag=true;
		}
		return flag;
				}
	public boolean validateAccname(String accName){
		boolean flag=true;
		Pattern pattern=Pattern.compile("[A-za-z]*");
		Matcher m = pattern.matcher(accName);
		if((m.matches()) && (accName.length()>2))
		{
			flag=false;
		}
		return flag;
	}
public boolean validateAddress(String addr){
	boolean flag=true;
	Pattern pattern=Pattern.compile("[A-Z]{1}[a-z]*");
	Matcher m = pattern.matcher(addr);
	if(m.matches())
	{
	 flag=false;
	}
	return flag;
}
	public boolean validatemobNum(String mobNum){
		boolean flag=true;
		Pattern pattern=Pattern.compile("[7-9][0-9]{9}");
		Matcher m = pattern.matcher(mobNum);
		if(m.matches())
		{
		 flag=false;
		}
		return flag;
	}
	public boolean validateidProof(String idProofNo){
		boolean flag=true;
		Pattern pattern=Pattern.compile("[0-9][0-9]{9}");
		Matcher m = pattern.matcher(idProofNo);
		if(m.matches())
		{
		 flag=false;
		}
		return flag;
	}
	public boolean validateAge(int age){
		boolean flag=true;
		if(age>18)
		{
			flag=false;
		}
		return flag;
	}
	
	public boolean validateEmailId(String emailid){
		boolean flag=true;
		Pattern pattern=Pattern.compile("[a-zA-Z0-9.]*@[a-zA-Z0-9]+([.][a-zA-z]+)");
		Matcher m = pattern.matcher(emailid);
		if(m.matches())
		{
		 flag=false;
		}
		return flag;
	}
	
	}

