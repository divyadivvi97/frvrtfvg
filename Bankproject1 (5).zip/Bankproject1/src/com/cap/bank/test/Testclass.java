package com.cap.bank.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.cap.bank.beans.Accountholder1;
import com.cap.bank.services.Accountholder1ServicesImp;

public class Testclass extends Accountholder1ServicesImp {
 
	Accountholder1 a= new Accountholder1();
	Accountholder1 b= new Accountholder1();
	
	Accountholder1ServicesImp c = new Accountholder1ServicesImp();
	@Test
	public void testCreateAccount() {
		//assertNotNull(c.createAccount(a));
		assertNotEquals(a, b);
	}

	

	@Test
	public void testShowBalance() {
		a.setBalance(2000.0);
		assertNotNull(a.getBalance());
		//(a.getBalance(), c.showBalance(a));
	}

	@Test
	public void testDeposit() {
		a.setBalance(3000.0);
		b.setBalance(3000.0);
		assertEquals(a.getBalance(), b.getBalance(),0.1);
		
	}

	@Test
	public void testWithDraw() {
		a.setBalance(3000.0);
		b.setBalance(2000.0);
		double withdraw=a.getBalance();
		assertNotEquals(a.getBalance(),b.getBalance(),0.1);
		
	}

	@Test
	public void testFundTransfer() {
		double amount=1000;
		
		assertTrue(amount>0);
	}

	@Test
	public void testPrintTransactions() {
		assertNotNull(c);
	}

}
