package com.cap.bank.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;




@Entity
@Table(name="Trans")
public class Transaction {
@Id
@GeneratedValue(strategy=GenerationType.IDENTITY)
private int transid;
private String transaction;
@ManyToOne
@JoinColumn(name="Accountholder1")
private Accountholder1 accountholder1;






public Transaction() {
	
}




public Transaction(int transid, String transaction,
		Accountholder1 accountholder1) {
	super();
	this.transid = transid;
	this.transaction = transaction;
	this.accountholder1 = accountholder1;
}




public int getTransid() {
	return transid;
}
public void setTransid(int transid) {
	this.transid = transid;
}
public String getTransaction() {
	return transaction;
}
public void setTransaction(String transaction) {
	this.transaction = transaction;
}
public Accountholder1 getAccountholder1() {
	return accountholder1;
}
public void setAccountholder1(Accountholder1 accountholder1) {
	this.accountholder1 = accountholder1;
}




@Override
public String toString() {
	return "Transaction [transaction=" + transaction + "]";
}








}
