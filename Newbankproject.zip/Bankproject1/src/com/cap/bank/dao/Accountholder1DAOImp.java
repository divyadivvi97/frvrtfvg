package com.cap.bank.dao;

import java.util.HashMap;

import com.cap.bank.beans.Accountholder1;



public class Accountholder1DAOImp implements IAccountholder1DAO{

	HashMap<Long,Accountholder1> acctList = new HashMap<Long,Accountholder1>();
	
	public boolean createAccount(Accountholder1 bean) {
		Long key=bean.getAccno();
		acctList.put(key,bean);
		return acctList.containsValue(bean);
		
	}
	public Accountholder1 displayAccountholder1(long id3) {
		Accountholder1 cust=null;
		for (Accountholder1 c : acctList.values()) {
      if(c.getAccno() == id3){
    	cust=c;  
      }
      }
		return cust;
	}

	public boolean valid(long id3)
	{ boolean flag=true;
		for (Accountholder1 c : acctList.values()) {
		      if(c.getAccno() == id3){
		    	 flag=false;
		      }
		      
		    	  
		      }
		return flag;
	}
	
	
	public boolean valid(int pin)
	{  boolean flag=true;
		for (Accountholder1 c : acctList.values()) {
		      if(c.getPin() == pin){
		    	  flag=false;;
		      }
		     
		      }
		return flag;
	}
	
	public double showBalance(Accountholder1 m) {
	            double balance=0;
	    		 balance= m.getBalance();
	    		 return balance;
	    	
           }
			public double deposit(Accountholder1 e,double amount) 
			{
				
				double currbal=0;
		              currbal=(currbal+e.getBalance()+amount);
		             e.setBalance(currbal);
				 return currbal;
			}
				
@Override
	public double withDraw(Accountholder1 d,double amount2) 
{ 
	double currbal=0;
	  
			         if(d.getBalance()-amount2>500) 
			        {
			         currbal=(currbal+d.getBalance()-amount2);
                     d.setBalance(currbal);
                   
                     }
			         else
			         return 0;
				
			  return currbal;
}
      
		

	@Override
	public int fundTransfer(Accountholder1 b,Accountholder1 c, double amount3)
	{
		  
		double currbal1=0;
		double currbal2=0;
			         if((amount3<b.getBalance())&&(b.getBalance()-amount3>500))
				                  {
				                           currbal1=(currbal1+b.getBalance()-amount3);
			                               b.setBalance(currbal1);
			                               currbal2=(currbal2+c.getBalance()+amount3);
				                           c.setBalance(currbal2);
				                    }
			                      else
			                    	  return 0;
			
			return 1;		
	}
			
		

		
	public boolean printTransactions(long id7){
		return false;
		
	}
	
	
	
	
	
	}

	

