package com.capgemini.employeeapp.dao;

import java.util.List;

import com.capgemini.employeeapp.dto.Employee;
import com.capgemini.employeeapp.exception.EmployeeException;

public interface EmployeeDao {
	List<Employee>getEmployees() throws EmployeeException;
	public String addEmployee(Employee employee ) throws EmployeeException;

}
