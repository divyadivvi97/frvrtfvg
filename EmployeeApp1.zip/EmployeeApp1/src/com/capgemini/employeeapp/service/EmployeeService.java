package com.capgemini.employeeapp.service;

import java.util.List;

import com.capgemini.employeeapp.dto.Employee;
import com.capgemini.employeeapp.exception.EmployeeException;

public interface EmployeeService {
	List<Employee>getEmployees() throws EmployeeException;
	public String addEmployee(Employee employee ) throws EmployeeException;
}
